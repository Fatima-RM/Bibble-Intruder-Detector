from flask import Flask, request, jsonify, render_template, session, redirect
from facial_recognition import FacialRecognition, get_time_based_greeting
import os
import json
from flask_cors import CORS

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'default_secret_key_for_development')

# Enable CORS for all routes to allow requests from our main app
CORS(app)

# Initialize facial recognition with slightly more lenient threshold based on our testing
face_recognizer = FacialRecognition(threshold=0.6)

@app.route('/')
def home():
    return jsonify({
        "status": "success",
        "message": "Face Recognition API is running",
        "known_faces_count": len(face_recognizer.known_face_encodings)
    })

@app.route('/api/recognize', methods=['POST'])
def recognize_face():
    """Recognize a face from a base64 image sent in the request"""
    if not request.json or 'image' not in request.json:
        return jsonify({
            "status": "error",
            "message": "No image data provided"
        }), 400
    
    # Get the base64 image from the request
    base64_image = request.json['image']
    
    # Recognize the face
    result = face_recognizer.recognize_face_from_base64(base64_image)
    
    # If recognized, generate a greeting
    if result['is_recognized']:
        greeting = get_time_based_greeting(result['name'])
        result['greeting'] = greeting
    
    return jsonify({
        "status": "success",
        "result": result
    })

@app.route('/api/register', methods=['POST'])
def register_face():
    """Register a new face using a base64 image"""
    required_fields = ['image', 'name', 'username', 'userId']
    
    if not request.json or not all(field in request.json for field in required_fields):
        return jsonify({
            "status": "error",
            "message": "Missing required fields: image, name, username, userId"
        }), 400
    
    # Extract data from request
    base64_image = request.json['image']
    name = request.json['name']
    username = request.json['username']
    user_id = int(request.json['userId'])
    
    # Add the face
    success = face_recognizer.add_face_from_base64(base64_image, name, username, user_id)
    
    if success:
        return jsonify({
            "status": "success",
            "message": f"Face for {name} registered successfully"
        })
    else:
        return jsonify({
            "status": "error",
            "message": "Failed to register face. Make sure a clear face is visible in the image."
        }), 400

@app.route('/api/regenerate-encodings', methods=['POST'])
def regenerate_encodings():
    """Force regeneration of all face encodings from the known_faces directory"""
    success = face_recognizer.generate_encodings_from_directory()
    
    if success:
        return jsonify({
            "status": "success",
            "message": f"Regenerated encodings for {len(face_recognizer.known_face_encodings)} faces"
        })
    else:
        return jsonify({
            "status": "error",
            "message": "Failed to regenerate encodings"
        }), 500

@app.route('/api/known-faces', methods=['GET'])
def list_known_faces():
    """Return a list of all known faces"""
    known_faces = []
    
    for i in range(len(face_recognizer.known_face_encodings)):
        known_faces.append({
            "id": i,
            "name": face_recognizer.known_face_names[i],
            "username": face_recognizer.known_face_usernames[i],
            "user_id": face_recognizer.known_face_user_ids[i]
        })
    
    return jsonify({
        "status": "success",
        "known_faces": known_faces
    })

# Run the Flask app if executed directly
if __name__ == '__main__':
    # First, generate encodings if needed
    if not face_recognizer.load_encodings():
        face_recognizer.generate_encodings_from_directory()
    
    # Start the server
    port = int(os.environ.get('PORT', 5001))  # Use PORT from environment or default to 5001
    app.run(host='0.0.0.0', port=port, debug=True)