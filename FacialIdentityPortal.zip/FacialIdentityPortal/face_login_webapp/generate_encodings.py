import face_recognition
import cv2
import os
import pickle

image_folder = 'known_faces'
known_encodings = []
known_names = []

for file in os.listdir(image_folder):
    img_path = os.path.join(image_folder, file)
    img = face_recognition.load_image_file(img_path)
    enc = face_recognition.face_encodings(img)[0]
    known_encodings.append(enc)
    known_names.append(os.path.splitext(file)[0])

with open('encodings.pickle', 'wb') as f:
    pickle.dump({'encodings': known_encodings, 'names': known_names}, f)
