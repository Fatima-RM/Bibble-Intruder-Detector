import face_recognition
import cv2
import numpy as np
import pickle

def recognize_face_from_image(img, known_face_encodings, known_face_names, threshold=0.42):
    small_img = cv2.resize(img, (0, 0), fx=0.25, fy=0.25)
    rgb_img = cv2.cvtColor(small_img, cv2.COLOR_BGR2RGB)

    face_locations = face_recognition.face_locations(rgb_img)
    face_encodings = face_recognition.face_encodings(rgb_img, face_locations)

    print(f"[INFO] Faces detected: {len(face_encodings)}")

    for face_encoding in face_encodings:
        face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
        best_match_index = np.argmin(face_distances)
        best_distance = face_distances[best_match_index]
        print(f"[INFO] Closest distance: {best_distance:.4f}")

        if best_distance < threshold:
            return known_face_names[best_match_index]

    return "Unknown"

def main():
    # Load known encodings
    with open("encodings.pickle", "rb") as f:
        data = pickle.load(f)
    known_face_encodings = data["encodings"]
    known_face_names = data["names"]

    # Open webcam
    print("[INFO] Starting camera...")
    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    cap.release()

    if not ret:
        print("[ERROR] Could not capture image from webcam.")
        return

    name = recognize_face_from_image(frame, known_face_encodings, known_face_names)
    print(f"[RESULT] Recognized as: {name}")

if __name__ == "__main__":
    main()
