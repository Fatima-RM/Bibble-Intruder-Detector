import face_recognition
import cv2
import numpy as np
import os
import pickle
import base64
from typing import List, Dict, Tuple, Union, Optional
import json

# Path to known faces directory
KNOWN_FACES_DIR = 'known_faces'
ENCODINGS_FILE = 'facial_encodings.pickle'

class FacialRecognition:
    def __init__(self, threshold: float = 0.5):
        """
        Initialize the facial recognition system
        
        Args:
            threshold: The maximum distance threshold for face matching (lower = stricter)
        """
        self.threshold = threshold
        self.known_face_encodings = []
        self.known_face_names = []
        self.known_face_usernames = []
        self.known_face_user_ids = []
        
        # Load existing encodings if available
        self.load_encodings()
    
    def load_encodings(self) -> bool:
        """Load known face encodings from pickle file if it exists"""
        try:
            if os.path.exists(ENCODINGS_FILE):
                with open(ENCODINGS_FILE, 'rb') as f:
                    data = pickle.load(f)
                    self.known_face_encodings = data.get('encodings', [])
                    self.known_face_names = data.get('names', [])
                    self.known_face_usernames = data.get('usernames', [])
                    self.known_face_user_ids = data.get('user_ids', [])
                print(f"Loaded {len(self.known_face_encodings)} face encodings")
                return True
            return False
        except Exception as e:
            print(f"Error loading encodings: {str(e)}")
            return False
    
    def generate_encodings_from_directory(self) -> bool:
        """Process all images in the known_faces directory to generate encodings"""
        try:
            # Clear existing data
            self.known_face_encodings = []
            self.known_face_names = []
            self.known_face_usernames = []
            self.known_face_user_ids = []
            
            # First level should be usernames
            for username in os.listdir(KNOWN_FACES_DIR):
                username_path = os.path.join(KNOWN_FACES_DIR, username)
                
                # Skip if not a directory
                if not os.path.isdir(username_path):
                    continue
                
                # Second level should be person names
                for name in os.listdir(username_path):
                    name_path = os.path.join(username_path, name)
                    
                    # If it's a directory with person name
                    if os.path.isdir(name_path):
                        # Process each image in the person's directory
                        for image_file in os.listdir(name_path):
                            if image_file.lower().endswith(('.png', '.jpg', '.jpeg')):
                                image_path = os.path.join(name_path, image_file)
                                self._process_image(image_path, name, username, len(self.known_face_names))
                    
                    # If it's an image file directly under username
                    elif name.lower().endswith(('.png', '.jpg', '.jpeg')):
                        image_path = os.path.join(username_path, name)
                        person_name = os.path.splitext(name)[0]  # Use filename as name
                        self._process_image(image_path, person_name, username, len(self.known_face_names))
            
            # Save the encodings
            self.save_encodings()
            print(f"Generated encodings for {len(self.known_face_encodings)} faces")
            return True
            
        except Exception as e:
            print(f"Error generating encodings: {str(e)}")
            return False
    
    def _process_image(self, image_path: str, name: str, username: str, user_id: int) -> bool:
        """Process a single image to extract face encoding"""
        try:
            print(f"Processing image: {image_path}")
            # Load the image
            image = face_recognition.load_image_file(image_path)
            
            # Find all faces in the image
            face_locations = face_recognition.face_locations(image)
            
            if len(face_locations) == 0:
                print(f"No faces found in {image_path}")
                return False
            
            # Get the encoding for the first face found
            face_encoding = face_recognition.face_encodings(image, face_locations)[0]
            
            # Store the encoding along with identity information
            self.known_face_encodings.append(face_encoding)
            self.known_face_names.append(name)
            self.known_face_usernames.append(username)
            self.known_face_user_ids.append(user_id)
            
            print(f"Added encoding for {name} ({username})")
            return True
            
        except Exception as e:
            print(f"Error processing image {image_path}: {str(e)}")
            return False
    
    def save_encodings(self) -> bool:
        """Save the current encodings to a pickle file"""
        try:
            with open(ENCODINGS_FILE, 'wb') as f:
                pickle.dump({
                    'encodings': self.known_face_encodings,
                    'names': self.known_face_names,
                    'usernames': self.known_face_usernames,
                    'user_ids': self.known_face_user_ids
                }, f)
            return True
        except Exception as e:
            print(f"Error saving encodings: {str(e)}")
            return False
    
    def add_face_from_base64(self, base64_image: str, name: str, username: str, user_id: int) -> bool:
        """Add a new face from a base64 encoded image string"""
        try:
            # Extract the actual base64 data without the prefix
            if ',' in base64_image:
                base64_image = base64_image.split(',')[1]
            
            # Decode base64 image
            img_bytes = base64.b64decode(base64_image)
            np_arr = np.frombuffer(img_bytes, np.uint8)
            img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            
            # Convert BGR to RGB (face_recognition uses RGB)
            rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            
            # Find faces in the image
            face_locations = face_recognition.face_locations(rgb_img)
            
            if len(face_locations) == 0:
                print("No face detected in the image")
                return False
            
            # Get the encoding for the first face found
            face_encoding = face_recognition.face_encodings(rgb_img, face_locations)[0]
            
            # Save the face to the appropriate directory
            os.makedirs(os.path.join(KNOWN_FACES_DIR, username, name), exist_ok=True)
            
            # Generate unique filename based on timestamp
            import time
            filename = f"{name}_{int(time.time())}.jpg"
            file_path = os.path.join(KNOWN_FACES_DIR, username, name, filename)
            
            # Save the image
            cv2.imwrite(file_path, img)
            
            # Store the encoding
            self.known_face_encodings.append(face_encoding)
            self.known_face_names.append(name)
            self.known_face_usernames.append(username)
            self.known_face_user_ids.append(user_id)
            
            # Save updated encodings
            self.save_encodings()
            
            print(f"Added new face encoding for {name} ({username})")
            return True
            
        except Exception as e:
            print(f"Error adding face from base64: {str(e)}")
            return False
    
    def recognize_face_from_base64(self, base64_image: str) -> Dict:
        """
        Recognize a face from a base64 encoded image string
        
        Returns:
            Dict with recognition results including:
            - is_recognized: bool
            - user_id: int or None
            - name: str or None
            - username: str or None
            - confidence: float or None
        """
        try:
            # Check if we have any known faces
            if len(self.known_face_encodings) == 0:
                return {
                    'is_recognized': False,
                    'error': 'No known faces in the database'
                }
            
            # Extract the actual base64 data without the prefix
            if ',' in base64_image:
                base64_image = base64_image.split(',')[1]
            
            # Decode base64 image
            img_bytes = base64.b64decode(base64_image)
            np_arr = np.frombuffer(img_bytes, np.uint8)
            img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            
            # Resize for faster processing
            small_img = cv2.resize(img, (0, 0), fx=0.25, fy=0.25)
            rgb_img = cv2.cvtColor(small_img, cv2.COLOR_BGR2RGB)
            
            # Find faces in the image
            face_locations = face_recognition.face_locations(rgb_img)
            
            if len(face_locations) == 0:
                return {
                    'is_recognized': False,
                    'error': 'No face detected in the image'
                }
            
            # Get the encoding for the first face found
            face_encoding = face_recognition.face_encodings(rgb_img, face_locations)[0]
            
            # Calculate distances to all known faces
            face_distances = face_recognition.face_distance(self.known_face_encodings, face_encoding)
            
            # Find the best match
            best_match_index = np.argmin(face_distances)
            best_distance = face_distances[best_match_index]
            
            print(f"Best match distance: {best_distance:.4f}, threshold: {self.threshold}")
            
            # Check if the match is good enough
            if best_distance <= self.threshold:
                # Calculate confidence (0 to 1)
                confidence = 1.0 - (best_distance / self.threshold)
                
                return {
                    'is_recognized': True,
                    'user_id': self.known_face_user_ids[best_match_index],
                    'name': self.known_face_names[best_match_index],
                    'username': self.known_face_usernames[best_match_index],
                    'confidence': confidence,
                    'distance': float(best_distance)
                }
            else:
                return {
                    'is_recognized': False,
                    'best_distance': float(best_distance),
                    'threshold': self.threshold,
                    'error': 'Face not recognized with required confidence'
                }
                
        except Exception as e:
            print(f"Error in face recognition: {str(e)}")
            return {
                'is_recognized': False,
                'error': str(e)
            }


# Helper function to get timebase greeting
def get_time_based_greeting(name: str) -> str:
    """Generate a time-appropriate greeting with the person's name"""
    import datetime
    
    hour = datetime.datetime.now().hour
    
    if hour < 12:
        greeting = "Good morning"
    elif hour < 18:
        greeting = "Good afternoon"
    else:
        greeting = "Good evening"
    
    return f"{greeting}, {name}!"


# If run directly, generate encodings from the directory
if __name__ == "__main__":
    face_rec = FacialRecognition(threshold=0.6)
    face_rec.generate_encodings_from_directory()
    print(f"Generated encodings for {len(face_rec.known_face_encodings)} faces")