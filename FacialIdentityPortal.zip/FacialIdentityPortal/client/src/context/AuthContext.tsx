import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';

interface User {
  id: number;
  name: string;
  email: string;
  username: string;
  faceIdEnabled: boolean;
  passwordEnabled: boolean;
}

interface AuthContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: User | null;
  login: (data: any, method: 'password' | 'face') => Promise<{
    success: boolean;
    user?: User;
    error?: string;
  }>;
  register: (data: any) => Promise<{
    success: boolean;
    user?: User;
    error?: string;
  }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  isLoading: true,
  user: null,
  login: async () => ({ success: false }),
  register: async () => ({ success: false }),
  logout: async () => {},
});

export const useAuth = () => useContext(AuthContext);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const login = async (data: any, method: 'password' | 'face') => {
    try {
      const endpoint = method === 'password' ? '/api/auth/login' : '/api/auth/face-login';
      const response = await apiRequest('POST', endpoint, data);
      const result = await response.json();
      
      setUser(result.user);
      queryClient.invalidateQueries();
      
      return {
        success: true,
        user: result.user,
      };
    } catch (error) {
      console.error(`${method} login error:`, error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Login failed',
      };
    }
  };

  const register = async (data: any) => {
    try {
      const response = await apiRequest('POST', '/api/auth/register', data);
      const result = await response.json();
      
      setUser(result.user);
      queryClient.invalidateQueries();
      
      return {
        success: true,
        user: result.user,
      };
    } catch (error) {
      console.error('Registration error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Registration failed',
      };
    }
  };

  const logout = async () => {
    try {
      await apiRequest('POST', '/api/auth/logout', {});
      setUser(null);
      queryClient.invalidateQueries();
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  useEffect(() => {
    async function checkAuthStatus() {
      try {
        const response = await fetch('/api/auth/me', {
          credentials: 'include',
        });
        
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
        }
      } catch (error) {
        console.error('Auth check error:', error);
      } finally {
        setIsLoading(false);
      }
    }
    
    checkAuthStatus();
  }, []);

  return (
    <AuthContext.Provider value={{
      isAuthenticated: !!user,
      isLoading,
      user,
      login,
      register,
      logout,
    }}>
      {children}
    </AuthContext.Provider>
  );
};
