import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import VideoStream from "@/components/VideoStream";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { registerUserSchema } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { CheckIcon } from "lucide-react";

type RegisterStep = 1 | 2 | 3;

export default function Register() {
  const [, setLocation] = useLocation();
  const { register: registerUser, isLoading } = useAuth();
  const { toast } = useToast();
  const [step, setStep] = useState<RegisterStep>(1);
  const [faceDetected, setFaceDetected] = useState(false);
  const [faceDescriptor, setFaceDescriptor] = useState<string | null>(null);
  const [faceDataUrl, setFaceDataUrl] = useState<string | null>(null);
  const [captureStatus, setCaptureStatus] = useState("Position your face in the circle");
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error' | 'warning', message: string } | null>(null);
  
  const form = useForm<z.infer<typeof registerUserSchema>>({
    resolver: zodResolver(registerUserSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
      username: "",
      faceDescriptor: "",
      faceDataUrl: "",
      faceIdEnabled: false,
      createdAt: "",
    },
  });

  const captureVideoRef = useRef<HTMLVideoElement | null>(null);

  const handleNext = async () => {
    if (step === 1) {
      // Validate form
      const valid = await form.trigger(["name", "email", "password", "confirmPassword"]);
      if (!valid) {
        setFeedbackMessage({
          type: 'error',
          message: 'Please fill in all fields correctly'
        });
        return;
      }
      
      setFeedbackMessage(null);
      setStep(2);
    } else if (step === 2) {
      if (!faceDetected || !faceDescriptor) {
        setFeedbackMessage({
          type: 'error',
          message: 'Please position your face in the circle'
        });
        return;
      }
      
      // Capture the face image
      if (captureVideoRef.current) {
        const canvas = document.createElement('canvas');
        canvas.width = captureVideoRef.current.videoWidth;
        canvas.height = captureVideoRef.current.videoHeight;
        const ctx = canvas.getContext('2d');
        
        if (ctx) {
          ctx.drawImage(captureVideoRef.current, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg');
          setFaceDataUrl(dataUrl);
        }
      }
      
      setFeedbackMessage(null);
      setStep(3);
    } else if (step === 3) {
      // Final registration
      try {
        const values = form.getValues();
        
        // Add the face data
        values.faceDescriptor = faceDescriptor || "";
        values.faceDataUrl = faceDataUrl || "";
        values.faceIdEnabled = true;
        values.createdAt = new Date().toISOString();
        
        const success = await registerUser(values);
        
        if (success) {
          toast({
            title: "Registration Successful",
            description: "Your account has been created with Face ID enabled.",
          });
          setLocation('/dashboard');
        } else {
          setFeedbackMessage({
            type: 'error',
            message: 'Registration failed. Please try again.'
          });
        }
      } catch (error) {
        setFeedbackMessage({
          type: 'error',
          message: 'Registration failed. Please try again.'
        });
      }
    }
  };

  const handleBack = () => {
    if (step === 1) {
      setLocation("/");
    } else {
      setStep(prev => (prev - 1) as RegisterStep);
      setFeedbackMessage(null);
    }
  };

  const handleCancel = () => {
    setLocation("/");
  };

  const handleFaceDetected = (detected: boolean) => {
    setFaceDetected(detected);
    if (detected) {
      setCaptureStatus("Face detected! Hold still...");
    } else {
      setCaptureStatus("Position your face in the circle");
    }
  };

  const handleFaceDescriptor = (descriptor: Float32Array) => {
    // Convert Float32Array to string for storage
    setFaceDescriptor(Array.from(descriptor).toString());
    setCaptureStatus("Face data captured successfully!");
  };

  return (
    <div className="max-w-md mx-auto">
      <Card className="bg-white rounded-lg shadow-md p-8">
        <CardContent className="p-0">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-neutral-800">Register New Face</h2>
            <p className="text-neutral-600 text-sm mt-1">Let's set up your facial recognition</p>
          </div>

          <div className="mb-6 space-y-4">
            {step === 1 && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <Label htmlFor="name">Your Name</Label>
                  <Input 
                    id="name" 
                    placeholder="Enter your full name"
                    {...form.register("name")}
                  />
                  {form.formState.errors.name && (
                    <p className="text-sm text-red-500">{form.formState.errors.name.message}</p>
                  )}
                </div>
                
                <div className="space-y-1">
                  <Label htmlFor="email">Email Address</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="you@example.com"
                    {...form.register("email")}
                  />
                  {form.formState.errors.email && (
                    <p className="text-sm text-red-500">{form.formState.errors.email.message}</p>
                  )}
                </div>
                
                <div className="space-y-1">
                  <Label htmlFor="password">Password</Label>
                  <Input 
                    id="password" 
                    type="password" 
                    placeholder="Create a password"
                    {...form.register("password")}
                  />
                  {form.formState.errors.password && (
                    <p className="text-sm text-red-500">{form.formState.errors.password.message}</p>
                  )}
                </div>
                
                <div className="space-y-1">
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input 
                    id="confirmPassword" 
                    type="password" 
                    placeholder="Confirm your password"
                    {...form.register("confirmPassword")}
                  />
                  {form.formState.errors.confirmPassword && (
                    <p className="text-sm text-red-500">{form.formState.errors.confirmPassword.message}</p>
                  )}
                </div>
              </div>
            )}

            {step === 2 && (
              <div>
                <VideoStream 
                  onFaceDetected={handleFaceDetected}
                  onFaceDescriptor={handleFaceDescriptor}
                  statusText={captureStatus}
                  captureMode={true}
                />
                
                <div className="mt-4 bg-neutral-100 rounded-md p-3">
                  <h4 className="text-sm font-medium text-neutral-800 mb-1">Tips for best results:</h4>
                  <ul className="text-xs text-neutral-600 space-y-1">
                    <li className="flex items-start">
                      <CheckIcon className="text-success h-4 w-4 mt-0.5 mr-1" />
                      Ensure your face is well-lit and clearly visible
                    </li>
                    <li className="flex items-start">
                      <CheckIcon className="text-success h-4 w-4 mt-0.5 mr-1" />
                      Remove glasses, hats, or other accessories
                    </li>
                    <li className="flex items-start">
                      <CheckIcon className="text-success h-4 w-4 mt-0.5 mr-1" />
                      Face the camera directly and maintain a neutral expression
                    </li>
                  </ul>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="py-8 flex flex-col items-center justify-center">
                <div className="mb-4 w-16 h-16 rounded-full bg-success/10 flex items-center justify-center">
                  <CheckIcon className="h-8 w-8 text-success" />
                </div>
                <h3 className="text-lg font-medium text-neutral-800 mb-1">Registration Complete!</h3>
                <p className="text-neutral-600 text-center mb-4">Your face has been registered successfully.</p>
                {faceDataUrl && (
                  <img 
                    src={faceDataUrl} 
                    className="w-32 h-32 object-cover rounded-lg border-2 border-success" 
                    alt="Captured face preview" 
                  />
                )}
              </div>
            )}
          </div>

          <div className="space-y-3">
            {feedbackMessage && (
              <div className={`py-3 px-4 rounded-md text-center text-sm font-medium
                ${feedbackMessage.type === 'success' ? 'bg-success/10 text-success' : ''}
                ${feedbackMessage.type === 'error' ? 'bg-error/10 text-error' : ''}
                ${feedbackMessage.type === 'warning' ? 'bg-warning/10 text-warning' : ''}
              `}>
                {feedbackMessage.message}
              </div>
            )}
            
            <div className="flex space-x-3">
              <Button 
                variant="secondary" 
                className="flex-1 bg-neutral-200 hover:bg-neutral-300 text-neutral-800"
                onClick={handleBack}
              >
                {step === 1 ? 'Cancel' : 'Back'}
              </Button>
              
              {step !== 3 ? (
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90 text-white"
                  onClick={handleNext}
                  disabled={isLoading}
                >
                  Next
                </Button>
              ) : (
                <Button 
                  className="flex-1 bg-success hover:bg-success/90 text-white"
                  onClick={handleNext}
                  disabled={isLoading}
                >
                  {isLoading ? "Processing..." : "Start Using FaceID"}
                </Button>
              )}
            </div>
            
            <div className="text-center">
              <Button 
                variant="link" 
                className="text-neutral-600 hover:text-neutral-800 text-sm font-medium"
                onClick={handleCancel}
              >
                Cancel registration
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
