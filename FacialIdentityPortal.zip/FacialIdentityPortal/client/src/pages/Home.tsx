import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShieldX, Camera, UserPlus } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();

  return (
    <div className="max-w-md mx-auto">
      <Card className="bg-white rounded-lg shadow-md p-8 text-center">
        <CardContent className="p-0">
          <div className="mb-8">
            <ShieldX className="text-primary h-12 w-12 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-neutral-800 mb-2">
              Facial Recognition Authentication
            </h2>
            <p className="text-neutral-600">Securely login with your face</p>
          </div>
          <div className="space-y-4">
            <Button
              className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-6"
              onClick={() => setLocation("/login")}
            >
              <Camera className="mr-2 h-5 w-5" /> Login with Face ID
            </Button>
            <Button
              variant="outline"
              className="w-full bg-white hover:bg-neutral-100 text-primary border border-primary font-medium py-6"
              onClick={() => setLocation("/register")}
            >
              <UserPlus className="mr-2 h-5 w-5" /> Register New Face
            </Button>
            <p className="text-xs text-neutral-500 mt-4">
              We use secure face-api.js technology to protect your biometric data.
              Your face data never leaves your device.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
