import React from 'react';
import AuthScreens from '@/components/AuthScreens';
import { useAuth } from '../context/AuthContext';
import { Redirect } from 'wouter';

const AuthPage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  
  if (isAuthenticated) {
    return <Redirect to="/dashboard" />;
  }

  return (
    <AuthScreens />
  );
};

export default AuthPage;
