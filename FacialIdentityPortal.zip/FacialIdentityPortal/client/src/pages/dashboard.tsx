import React from 'react';
import Dashboard from '@/components/Dashboard';
import { useAuth } from '../context/AuthContext';
import { Redirect } from 'wouter';

const DashboardPage: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return <Redirect to="/auth" />;
  }

  return (
    <Dashboard />
  );
};

export default DashboardPage;
