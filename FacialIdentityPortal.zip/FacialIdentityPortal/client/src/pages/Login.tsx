import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import VideoStream from "@/components/VideoStream";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [, setLocation] = useLocation();
  const { loginWithFace, isLoading } = useAuth();
  const { toast } = useToast();
  const [faceDetected, setFaceDetected] = useState(false);
  const [faceDescriptor, setFaceDescriptor] = useState<Float32Array | null>(null);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error' | 'warning', message: string } | null>(null);
  const [recognitionStatus, setRecognitionStatus] = useState("Looking for face...");

  // Auto login when face descriptor is available
  useEffect(() => {
    if (faceDescriptor && !isLoading) {
      const attemptLogin = async () => {
        setRecognitionStatus("Verifying identity...");
        try {
          // Convert Float32Array to string for API transit
          const descriptorString = Array.from(faceDescriptor).toString();
          const success = await loginWithFace(descriptorString);
          
          if (success) {
            setFeedbackMessage({ type: 'success', message: '✓ Face recognized! Logging you in...' });
            setTimeout(() => {
              setLocation('/dashboard');
            }, 1000);
          } else {
            setFeedbackMessage({ type: 'error', message: '✗ Face not recognized. Please try again or use password.' });
          }
        } catch (error) {
          setFeedbackMessage({ type: 'error', message: '✗ Authentication failed. Please try again.' });
        }
      };
      
      attemptLogin();
    }
  }, [faceDescriptor, loginWithFace, setLocation, isLoading]);

  const handleRetry = () => {
    setFeedbackMessage(null);
    setFaceDescriptor(null);
  };

  const handleCancel = () => {
    setLocation("/");
  };

  const handlePasswordLogin = () => {
    setLocation("/password-login");
  };

  return (
    <div className="max-w-md mx-auto">
      <Card className="bg-white rounded-lg shadow-md p-8">
        <CardContent className="p-0">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-neutral-800">Login with Face ID</h2>
            <p className="text-neutral-600 text-sm mt-1">Position your face in the frame</p>
          </div>
          
          <VideoStream 
            onFaceDetected={setFaceDetected} 
            onFaceDescriptor={(descriptor) => {
              if (!faceDescriptor && !isLoading) {
                setFaceDescriptor(descriptor);
              }
            }}
            statusText={recognitionStatus}
          />

          <div className="space-y-3">
            {feedbackMessage && (
              <div className={`py-3 px-4 rounded-md text-center text-sm font-medium
                ${feedbackMessage.type === 'success' ? 'bg-success/10 text-success' : ''}
                ${feedbackMessage.type === 'error' ? 'bg-error/10 text-error' : ''}
                ${feedbackMessage.type === 'warning' ? 'bg-warning/10 text-warning' : ''}
              `}>
                {feedbackMessage.message}
              </div>
            )}
            
            <div className="flex space-x-3">
              <Button 
                variant="secondary" 
                className="flex-1 bg-neutral-200 hover:bg-neutral-300 text-neutral-800"
                onClick={handleCancel}
              >
                Cancel
              </Button>
              
              {feedbackMessage?.type === 'error' && (
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90 text-white"
                  onClick={handleRetry}
                >
                  Retry
                </Button>
              )}
            </div>
            
            <div className="text-center">
              <Button 
                variant="link" 
                className="text-primary hover:text-primary/80 text-sm font-medium"
                onClick={handlePasswordLogin}
              >
                Login with password instead
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
