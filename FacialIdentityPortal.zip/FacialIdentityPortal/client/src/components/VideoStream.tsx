import { useRef, useEffect, useState, useCallback } from "react";
import { useFaceDetection } from "@/lib/faceRecognition";
import { Button } from "@/components/ui/button";
import { AlertCircle, Camera, CameraOff, Info } from "lucide-react";

interface VideoStreamProps {
  onFaceDetected?: (faceDetected: boolean) => void;
  onFaceDescriptor?: (descriptor: Float32Array) => void;
  showFeedback?: boolean;
  statusText?: string;
  captureMode?: boolean;
}

export default function VideoStream({
  onFaceDetected,
  onFaceDescriptor,
  showFeedback = true,
  statusText = "Looking for face...",
  captureMode = false,
}: VideoStreamProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState(statusText);
  const [isInitialized, setIsInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [showInstructions, setShowInstructions] = useState(false);

  const { startVideo, stopVideo, detectFace, error: cameraError } = useFaceDetection({
    videoElement: videoRef.current,
    onFaceDetectionResult: (result) => {
      if (result?.faceDetected) {
        const newStatus = "Face detected";
        setStatus(newStatus);
        // Announce status change for screen readers
        announceStatus(newStatus);
        onFaceDetected?.(true);
        
        if (result.faceDescriptor && onFaceDescriptor) {
          onFaceDescriptor(result.faceDescriptor);
          // Announce for screen readers when face is captured
          if (captureMode) {
            announceStatus("Face data captured successfully");
          }
        }
      } else {
        const newStatus = "Position your face in the circle";
        setStatus(newStatus);
        onFaceDetected?.(false);
      }
    },
  });

  // Function to announce status changes for screen readers
  const announceStatus = (message: string) => {
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'assertive');
    announcement.setAttribute('role', 'status');
    announcement.className = 'sr-only';
    announcement.innerText = message;
    document.body.appendChild(announcement);
    
    // Remove after screen reader has had time to read it
    setTimeout(() => {
      document.body.removeChild(announcement);
    }, 3000);
  };

  const handleStartCamera = useCallback(async () => {
    try {
      setError(null);
      console.log("Starting video camera...");
      
      // Directly access the camera to ensure it works
      if (videoRef.current) {
        console.log("Video ref found, attempting to access camera");
        
        // Try multiple camera constraints to maximize compatibility
        const constraintOptions = [
          // First try HD resolution for better face detection 
          { 
            video: { 
              width: { ideal: 1280 },
              height: { ideal: 720 },
              facingMode: "user"
            }, 
            audio: false 
          },
          // Then try standard resolution
          { 
            video: { 
              width: { ideal: 640 },
              height: { ideal: 480 },
              facingMode: "user"
            }, 
            audio: false 
          },
          // Finally, try with minimal constraints
          { 
            video: true, 
            audio: false 
          }
        ];
        
        let stream = null;
        let errorInfo = null;
        
        // Try each constraint option in order until one works
        for (const constraints of constraintOptions) {
          try {
            console.log("Requesting camera with constraints:", constraints);
            stream = await navigator.mediaDevices.getUserMedia(constraints);
            console.log("Camera access granted with constraints:", constraints);
            break; // Exit the loop if successful
          } catch (e) {
            console.log("Failed with constraints:", constraints, e);
            errorInfo = e; // Save the last error
            // Continue to the next constraint option
          }
        }
        
        if (!stream) {
          throw errorInfo || new Error("Could not access camera with any constraints");
        }
        
        // Attach stream to video element
        videoRef.current.srcObject = stream;
        
        // Set up video element events
        videoRef.current.onloadedmetadata = () => {
          console.log("Video element metadata loaded");
          if (videoRef.current) {
            videoRef.current.play()
              .then(() => console.log("Video playing successfully"))
              .catch(e => console.error("Error playing video:", e));
          }
        };
        
        // Better error handling
        videoRef.current.onerror = (e) => {
          console.error("Video element error:", e);
          setError("Error with video playback. Please try refreshing the page.");
        };
        
        setIsCameraOn(true);
        setIsInitialized(true);
        
        // Start face-api.js models initialization
        await startVideo().catch(e => {
          console.warn("Face detection initialization warning:", e);
          // Continue anyway as the camera is working
        });
        
        announceStatus("Camera started. Please position your face clearly in the center circle for detection.");
      } else {
        throw new Error("Video element not found");
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      
      // More specific error messages based on error type
      let errorMessage = "Could not access camera. Please ensure camera permissions are granted.";
      
      if (err instanceof Error) {
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          errorMessage = "Camera access denied. Please allow camera access in your browser settings.";
        } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
          errorMessage = "No camera detected. Please connect a camera and try again.";
        } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
          errorMessage = "Camera is in use by another application. Please close other applications and try again.";
        } else if (err.name === 'OverconstrainedError') {
          errorMessage = "Your camera does not support the required resolution. Please try a different browser.";
        }
      }
      
      setError(errorMessage);
      setIsCameraOn(false);
      announceStatus(errorMessage);
    }
  }, [startVideo]);

  const handleStopCamera = useCallback(() => {
    console.log("Stopping video camera...");
    
    // Stop camera directly
    if (videoRef.current && videoRef.current.srcObject) {
      try {
        const stream = videoRef.current.srcObject as MediaStream;
        const tracks = stream.getTracks();
        tracks.forEach(track => {
          console.log("Stopping track:", track);
          track.stop();
        });
        videoRef.current.srcObject = null;
        console.log("Camera successfully stopped");
      } catch (err) {
        console.error("Error stopping camera:", err);
      }
    }
    
    setIsCameraOn(false);
    announceStatus("Camera stopped");
  }, []);

  const toggleInstructions = () => {
    setShowInstructions(prev => !prev);
    announceStatus(showInstructions ? "Instructions closed" : "Instructions opened");
  };

  useEffect(() => {
    if (cameraError) {
      setError(cameraError);
      announceStatus(`Error: ${cameraError}`);
    }
  }, [cameraError]);

  useEffect(() => {
    // Use a timeout for auto-start to ensure the component is fully rendered
    const autoStartTimer = setTimeout(() => {
      // Auto-start camera if not initialized yet
      if (!isInitialized && !isCameraOn) {
        console.log("Attempting to auto-start camera...");
        handleStartCamera().catch(err => {
          console.error("Auto camera start failed:", err);
          // Already handled in handleStartCamera
        });
      }
    }, 500); // Shorter timeout for faster initialization

    // Set up keyboard navigation for the video container
    const handleKeyDown = (e: KeyboardEvent) => {
      if (containerRef.current && containerRef.current.contains(document.activeElement)) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          if (isCameraOn) {
            handleStopCamera();
          } else {
            handleStartCamera().catch(err => {
              console.error("Keyboard camera start failed:", err);
              // Already handled in handleStartCamera
            });
          }
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      clearTimeout(autoStartTimer);
      document.removeEventListener('keydown', handleKeyDown);
      // Ensure camera is turned off when component unmounts
      if (isCameraOn) {
        handleStopCamera();
      }
    };
  }, [isInitialized, isCameraOn, handleStartCamera, handleStopCamera, stopVideo]);

  useEffect(() => {
    let detectionInterval: number;

    if (isInitialized && isCameraOn) {
      // Start face detection with an interval
      detectionInterval = window.setInterval(() => {
        detectFace();
      }, 100);
    }

    return () => {
      if (detectionInterval) {
        clearInterval(detectionInterval);
      }
    };
  }, [isInitialized, isCameraOn, detectFace]);

  return (
    <div className="relative mb-6" aria-labelledby="face-recognition-title" role="region">
      <div className="flex justify-between items-center mb-2">
        <h3 id="face-recognition-title" className="text-lg font-medium">Face Recognition</h3>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={toggleInstructions}
            aria-label={showInstructions ? "Hide accessibility instructions" : "Show accessibility instructions"}
            title={showInstructions ? "Hide instructions" : "Show instructions"}
          >
            <Info className="h-4 w-4 mr-1" />
            {showInstructions ? "Hide Info" : "Info"}
          </Button>
          
          <Button 
            variant={isCameraOn ? "destructive" : "default"} 
            size="sm"
            onClick={isCameraOn ? handleStopCamera : handleStartCamera}
            aria-label={isCameraOn ? "Turn camera off" : "Turn camera on"}
          >
            {isCameraOn ? (
              <>
                <CameraOff className="h-4 w-4 mr-1" /> Stop Camera
              </>
            ) : (
              <>
                <Camera className="h-4 w-4 mr-1" /> Start Camera
              </>
            )}
          </Button>
        </div>
      </div>

      {showInstructions && (
        <div className="bg-blue-50 p-3 rounded-md text-sm mb-3 border border-blue-200" role="region" aria-label="Accessibility instructions">
          <h4 className="font-medium text-blue-800 mb-1">Accessibility Instructions:</h4>
          <ul className="list-disc pl-5 text-blue-700 space-y-1">
            <li>Position your face in the center circle for best detection</li>
            <li>Good lighting on your face improves recognition accuracy</li>
            <li>Press Space or Enter to toggle the camera on/off when focused</li>
            <li>Face data is processed locally for your privacy</li>
            <li>Audio feedback is provided for key actions</li>
          </ul>
        </div>
      )}

      <div 
        className="aspect-w-4 aspect-h-3 bg-neutral-200 rounded-lg overflow-hidden relative"
        ref={containerRef}
        tabIndex={0}
        role="application"
        aria-label="Face recognition camera"
        aria-describedby="camera-status"
      >
        {/* Add high contrast mode detection border for accessibility */}
        <div 
          className="absolute inset-0 border-4 border-dashed border-primary/70 pointer-events-none rounded-lg"
          aria-hidden="true"
        ></div>
        
        <video
          ref={videoRef}
          className="object-cover w-full h-full"
          autoPlay
          muted
          playsInline
          aria-hidden="true" // Hide from screen readers as we provide status separately
        />
        
        {/* High contrast face positioning guide */}
        <div 
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
          aria-hidden="true"
        >
          <div className="w-48 h-48 border-4 border-primary rounded-full"></div>
        </div>

        {/* Show error state if camera fails */}
        {error && (
          <div 
            className="absolute inset-0 flex items-center justify-center bg-neutral-800/80"
            role="alert"
            aria-live="assertive"
          >
            <div className="text-center p-4 bg-white rounded-lg max-w-xs shadow-lg">
              <AlertCircle className="h-8 w-8 text-red-500 mx-auto mb-2" />
              <h4 className="font-bold text-neutral-800">Camera Access Issue</h4>
              <p className="text-neutral-600 text-sm mt-1">{error}</p>
              
              <div className="mt-4 space-y-2">
                <Button 
                  className="w-full" 
                  size="sm" 
                  onClick={handleStartCamera}
                  aria-label="Try accessing camera again"
                >
                  Try Again
                </Button>
                
                <div className="text-xs text-neutral-500 pt-2 pb-1">
                  <hr className="mb-2" />
                  <span>Common Solutions:</span>
                </div>
                
                <ul className="text-left text-xs text-neutral-600 space-y-1 pl-1">
                  <li>• Check browser permissions in settings</li>
                  <li>• Try a different browser (Chrome/Firefox recommended)</li>
                  <li>• Make sure no other apps are using your camera</li>
                  <li>• On some devices, try refreshing the page</li>
                </ul>
                
                <div className="text-xs text-neutral-600 mt-1 pt-1 border-t border-neutral-200">
                  <a 
                    href="#" 
                    className="text-primary underline"
                    onClick={(e) => {
                      e.preventDefault();
                      announceStatus("Using password authentication option instead");
                      // Typically we'd navigate or show password option here
                    }}
                    aria-label="Use password login instead of face recognition"
                  >
                    Use password authentication instead
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Status indicator with improved contrast */}
      {showFeedback && (
        <div 
          className="absolute inset-x-0 bottom-4 flex justify-center items-center"
          id="camera-status"
          aria-live="polite"
          role="status"
        >
          <div className="bg-neutral-900 text-white text-sm py-2 px-4 rounded-full flex items-center shadow-lg">
            <span className="font-medium">{status}</span>
            <div className="ml-3 flex space-x-1">
              <div className="h-2 w-2 bg-primary rounded-full animate-pulse"></div>
              <div className="h-2 w-2 bg-primary rounded-full animate-pulse delay-75"></div>
              <div className="h-2 w-2 bg-primary rounded-full animate-pulse delay-150"></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
