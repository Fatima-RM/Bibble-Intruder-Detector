import React, { useRef, useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '../context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { loadModels, getFaceDescriptors, descriptorToArray } from '../lib/faceRecognition';
import { registerSchema } from '@shared/schema';

interface RegisterScreenProps {
  onCancel: () => void;
}

const RegisterScreen: React.FC<RegisterScreenProps> = ({ onCancel }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { register } = useAuth();
  const { toast } = useToast();

  const [step, setStep] = useState(1);
  const [capturedFaceData, setCapturedFaceData] = useState<number[] | null>(null);
  const [captureStatus, setCaptureStatus] = useState('Position your face in the circle');
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackType, setFeedbackType] = useState<'success' | 'error' | 'warning'>('success');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [isCapturing, setIsCapturing] = useState(false);
  
  const form = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: '',
      email: '',
      username: '',
      password: '',
      confirmPassword: '',
      faceIdEnabled: true,
      passwordEnabled: true,
    },
  });

  useEffect(() => {
    let stream: MediaStream | null = null;
    
    async function setupCamera() {
      if (step !== 2) return;
      
      try {
        await loadModels();
        
        if (videoRef.current) {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'user' },
            audio: false
          });
          
          videoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing camera:', error);
        setFeedbackType('error');
        setFeedbackMessage('Failed to access camera. Please make sure camera permissions are granted.');
        setShowFeedback(true);
      }
    }
    
    setupCamera();
    
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => {
          track.stop();
        });
      }
    };
  }, [step]);

  const captureFace = async () => {
    if (!videoRef.current || isCapturing) return;
    
    setIsCapturing(true);
    setCaptureStatus('Detecting face...');
    
    try {
      const faceDescriptor = await getFaceDescriptors(videoRef.current);
      
      if (!faceDescriptor) {
        setCaptureStatus('No face detected. Please position your face in the circle.');
        setIsCapturing(false);
        return;
      }
      
      setCaptureStatus('Face detected! Processing...');
      
      // Take a screenshot of the current video frame
      if (videoRef.current && canvasRef.current) {
        const context = canvasRef.current.getContext('2d');
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context?.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
      }
      
      // Convert descriptor to array for storing
      const descriptorArray = descriptorToArray(faceDescriptor);
      setCapturedFaceData(descriptorArray);
      
      setCaptureStatus('Face captured successfully!');
      
      // Go to next step
      setTimeout(() => {
        setStep(3);
      }, 1000);
    } catch (error) {
      console.error('Error capturing face:', error);
      setCaptureStatus('Error capturing face. Please try again.');
    } finally {
      setIsCapturing(false);
    }
  };

  const nextStep = async () => {
    if (step === 1) {
      const valid = await form.trigger(['name', 'email', 'username', 'password', 'confirmPassword']);
      if (!valid) return;
      
      setStep(2);
    } else if (step === 2) {
      await captureFace();
    }
  };

  const prevStep = () => {
    if (step === 1) {
      onCancel();
    } else {
      setStep(step - 1);
    }
  };

  const finishRegistration = async () => {
    if (!capturedFaceData) {
      setFeedbackType('error');
      setFeedbackMessage('Face data is missing. Please go back and try again.');
      setShowFeedback(true);
      return;
    }
    
    try {
      const formData = form.getValues();
      
      const result = await register({
        ...formData,
        faceData: capturedFaceData,
      });
      
      if (result.success) {
        toast({
          title: "Registration Complete",
          description: "Your account has been created successfully!",
        });
      } else {
        setFeedbackType('error');
        setFeedbackMessage(result.error || 'Registration failed. Please try again.');
        setShowFeedback(true);
      }
    } catch (error) {
      console.error('Registration error:', error);
      setFeedbackType('error');
      setFeedbackMessage('An error occurred during registration. Please try again.');
      setShowFeedback(true);
    }
  };

  return (
    <Card className="bg-white rounded-lg shadow-md p-8">
      <CardContent className="p-0">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-neutral-800">Register New Face</h2>
          <p className="text-neutral-600 text-sm mt-1">Let's set up your facial recognition</p>
        </div>

        <div className="mb-6 space-y-4">
          {step === 1 && (
            <Form {...form}>
              <form className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Your Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your full name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="you@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input placeholder="Choose a username" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Create a password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Confirm Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Confirm your password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </form>
            </Form>
          )}

          {step === 2 && (
            <div>
              <div className="relative">
                <div className="aspect-w-4 aspect-h-3 bg-neutral-200 rounded-lg overflow-hidden relative">
                  <video 
                    ref={videoRef} 
                    className="object-cover w-full h-full" 
                    autoPlay 
                    muted 
                    playsInline
                  ></video>
                  <canvas 
                    ref={canvasRef} 
                    className="hidden"
                  ></canvas>
                  <div className="absolute inset-0 border-2 border-dashed border-primary/50 pointer-events-none rounded-lg"></div>
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-48 h-48 border-2 border-primary rounded-full"></div>
                  </div>
                </div>
                
                <div className="absolute inset-x-0 bottom-4 flex justify-center items-center">
                  <div className="bg-neutral-800/80 text-white text-sm py-1 px-3 rounded-full">
                    <span>{captureStatus}</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 bg-neutral-100 rounded-md p-3">
                <h4 className="text-sm font-medium text-neutral-800 mb-1">Tips for best results:</h4>
                <ul className="text-xs text-neutral-600 space-y-1">
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-success mt-0.5 mr-1"></i>
                    Ensure your face is well-lit and clearly visible
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-success mt-0.5 mr-1"></i>
                    Remove glasses, hats, or other accessories
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-success mt-0.5 mr-1"></i>
                    Face the camera directly and maintain a neutral expression
                  </li>
                </ul>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="py-8 flex flex-col items-center justify-center">
              <div className="mb-4 w-16 h-16 rounded-full bg-success/10 flex items-center justify-center">
                <i className="fas fa-check text-3xl text-success"></i>
              </div>
              <h3 className="text-lg font-medium text-neutral-800 mb-1">Registration Complete!</h3>
              <p className="text-neutral-600 text-center mb-4">Your face has been registered successfully.</p>
              
              {canvasRef.current && (
                <div className="w-32 h-32 object-cover rounded-lg border-2 border-success overflow-hidden">
                  <img 
                    src={canvasRef.current.toDataURL('image/png')} 
                    className="w-full h-full object-cover"
                    alt="Captured face preview"
                  />
                </div>
              )}
            </div>
          )}
        </div>

        <div className="space-y-3">
          {showFeedback && (
            <div className={`py-3 px-4 rounded-md text-center text-sm font-medium ${
              feedbackType === 'success' 
                ? 'bg-success/10 text-success' 
                : feedbackType === 'warning'
                ? 'bg-warning/10 text-warning'
                : 'bg-error/10 text-error'
            }`}>
              {feedbackMessage}
            </div>
          )}
          
          <div className="flex space-x-3">
            <Button 
              type="button"
              variant="secondary"
              className="flex-1"
              onClick={prevStep}
            >
              {step === 1 ? 'Cancel' : 'Back'}
            </Button>
            
            {step < 3 ? (
              <Button 
                type="button"
                className="flex-1"
                onClick={nextStep}
                disabled={isCapturing}
              >
                {isCapturing ? 'Processing...' : 'Next'}
              </Button>
            ) : (
              <Button 
                type="button"
                className="flex-1 bg-success hover:bg-success/90 text-white"
                onClick={finishRegistration}
              >
                Start Using FaceID
              </Button>
            )}
          </div>
          
          <div className="text-center">
            <Button 
              type="button"
              variant="link" 
              className="text-neutral-600 hover:text-neutral-800 text-sm font-medium"
              onClick={onCancel}
            >
              Cancel registration
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RegisterScreen;
