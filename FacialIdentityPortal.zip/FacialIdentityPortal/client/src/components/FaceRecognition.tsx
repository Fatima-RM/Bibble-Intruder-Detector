import React, { useEffect, useRef, useState } from 'react';
import * as faceapi from 'face-api.js';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface FaceRecognitionProps {
  mode: 'register' | 'login';
  onCapture?: (faceDescriptor: number[][]) => void;
  onRecognize?: (faceDescriptor: number[], userId: number) => void;
  referenceData?: { userId: number; descriptors: number[][] }[];
  facingMode?: 'user' | 'environment';
}

const FaceRecognition: React.FC<FaceRecognitionProps> = ({
  mode,
  onCapture,
  onRecognize,
  referenceData = [],
  facingMode = 'user',
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [detectionStatus, setDetectionStatus] = useState('Initializing camera...');
  const [isCameraRunning, setIsCameraRunning] = useState(false);
  const [capturedDescriptors, setCapturedDescriptors] = useState<number[][]>([]);
  const [showRetry, setShowRetry] = useState(false);
  const { toast } = useToast();
  
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // Load face-api.js models
  useEffect(() => {
    const loadModels = async () => {
      try {
        setDetectionStatus('Loading face recognition models...');
        
        // Load models from CDN
        const MODEL_URL = 'https://justadudewhohacks.github.io/face-api.js/models';
        
        await Promise.all([
          faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
          faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
          faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
        ]);
        
        setIsModelLoaded(true);
        setDetectionStatus('Models loaded. Starting camera...');
      } catch (error) {
        console.error('Error loading models:', error);
        setDetectionStatus('Failed to load face recognition models.');
        toast({
          title: "Model Loading Error",
          description: "Could not load face recognition models. Please try again.",
          variant: "destructive",
        });
      }
    };

    loadModels();
    
    // Clean up when component unmounts
    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Start the camera when models are loaded
  useEffect(() => {
    if (isModelLoaded && !isCameraRunning) {
      startCamera();
    }
  }, [isModelLoaded]);

  const startCamera = async () => {
    if (!videoRef.current) return;
    
    try {
      setDetectionStatus('Accessing camera...');
      
      // Stop any existing stream
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
      
      // Request camera access
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode,
          width: { ideal: 640 },
          height: { ideal: 480 }
        }
      });
      
      mediaStreamRef.current = stream;
      videoRef.current.srcObject = stream;
      
      // Wait for video to start playing
      await new Promise<void>((resolve) => {
        if (videoRef.current) {
          videoRef.current.onloadedmetadata = () => {
            if (videoRef.current) {
              videoRef.current.play();
              setIsCameraRunning(true);
              setDetectionStatus('Camera ready. Detecting face...');
              resolve();
            }
          };
        }
      });
      
      // Start face detection
      if (mode === 'register') {
        detectFacesForRegistration();
      } else {
        detectFacesForLogin();
      }
    } catch (error) {
      console.error('Error starting camera:', error);
      setDetectionStatus('Camera access denied or not available.');
      toast({
        title: "Camera Error",
        description: "Could not access your camera. Please check permissions and try again.",
        variant: "destructive",
      });
    }
  };

  const detectFacesForRegistration = async () => {
    if (!videoRef.current || !canvasRef.current || !isCameraRunning) return;
    
    try {
      const descriptors: number[][] = [];
      
      // We'll collect 3 face samples for better accuracy
      for (let i = 0; i < 3; i++) {
        setDetectionStatus(`Capturing face sample ${i + 1}/3...`);
        
        // Wait 1 second between captures
        if (i > 0) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
        
        // Detect face
        const detection = await faceapi
          .detectSingleFace(videoRef.current)
          .withFaceLandmarks()
          .withFaceDescriptor();
        
        if (!detection) {
          setDetectionStatus('No face detected. Please center your face and ensure good lighting.');
          setShowRetry(true);
          return;
        }
        
        // Draw face detection overlay
        const canvas = canvasRef.current;
        const displaySize = { width: videoRef.current.width, height: videoRef.current.height };
        faceapi.matchDimensions(canvas, displaySize);
        
        const resizedDetection = faceapi.resizeResults(detection, displaySize);
        canvas.getContext('2d')?.clearRect(0, 0, canvas.width, canvas.height);
        faceapi.draw.drawDetections(canvas, [resizedDetection]);
        faceapi.draw.drawFaceLandmarks(canvas, [resizedDetection]);
        
        // Store face descriptor
        descriptors.push(Array.from(detection.descriptor));
        
        setDetectionStatus(`Sample ${i + 1}/3 captured successfully!`);
      }
      
      setCapturedDescriptors(descriptors);
      setDetectionStatus('Face captured successfully! Processing...');
      
      // Callback with face data
      if (onCapture) {
        onCapture(descriptors);
      }
    } catch (error) {
      console.error('Error in face registration:', error);
      setDetectionStatus('Error processing face data.');
      setShowRetry(true);
      toast({
        title: "Face Detection Error",
        description: "There was a problem capturing your face. Please try again.",
        variant: "destructive",
      });
    }
  };

  const detectFacesForLogin = async () => {
    if (!videoRef.current || !canvasRef.current || !isCameraRunning) return;
    
    const canvas = canvasRef.current;
    const displaySize = { width: videoRef.current.width, height: videoRef.current.height };
    faceapi.matchDimensions(canvas, displaySize);
    
    const detectFace = async () => {
      try {
        if (!videoRef.current || !canvasRef.current) return;
        
        // Detect face
        const detection = await faceapi
          .detectSingleFace(videoRef.current)
          .withFaceLandmarks()
          .withFaceDescriptor();
        
        // Clear previous drawings
        canvas.getContext('2d')?.clearRect(0, 0, canvas.width, canvas.height);
        
        if (detection) {
          // Draw face detection overlay
          const resizedDetection = faceapi.resizeResults(detection, displaySize);
          faceapi.draw.drawDetections(canvas, [resizedDetection]);
          faceapi.draw.drawFaceLandmarks(canvas, [resizedDetection]);
          
          setDetectionStatus('Matching face...');
          
          // Check if this face matches any registered users
          if (referenceData.length > 0) {
            // Check against all reference face data
            let bestMatch: { userId: number; distance: number } | null = null;
            let smallestDistance = 0.6; // Threshold for face matching
            
            for (const reference of referenceData) {
              for (const descriptor of reference.descriptors) {
                // Calculate Euclidean distance
                const distance = faceapi.euclideanDistance(
                  detection.descriptor, 
                  new Float32Array(descriptor)
                );
                
                if (distance < smallestDistance) {
                  smallestDistance = distance;
                  bestMatch = {
                    userId: reference.userId,
                    distance
                  };
                }
              }
            }
            
            if (bestMatch) {
              setDetectionStatus('Face recognized! Logging in...');
              
              // Call the onRecognize callback with the match
              if (onRecognize) {
                onRecognize(Array.from(detection.descriptor), bestMatch.userId);
              }
              return; // Stop detection loop
            } else {
              setDetectionStatus('Face not recognized. Please try again or use password login.');
              setShowRetry(true);
            }
          } else {
            setDetectionStatus('No registered users found for face comparison.');
            setShowRetry(true);
          }
        } else {
          setDetectionStatus('No face detected. Please center your face and ensure good lighting.');
        }
        
        // Continue detection loop
        requestAnimationFrame(detectFace);
      } catch (error) {
        console.error('Error in face login:', error);
        setDetectionStatus('Error processing face data.');
        setShowRetry(true);
        toast({
          title: "Face Detection Error",
          description: "There was a problem recognizing your face. Please try again.",
          variant: "destructive",
        });
      }
    };
    
    // Start detection loop
    detectFace();
  };

  const handleRetry = () => {
    setShowRetry(false);
    setCapturedDescriptors([]);
    
    // Clear canvas
    if (canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        context.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      }
    }
    
    // Restart face detection
    if (mode === 'register') {
      detectFacesForRegistration();
    } else {
      detectFacesForLogin();
    }
  };

  return (
    <div className="face-recognition">
      <div className="relative aspect-[4/3] bg-neutral-200 rounded-lg overflow-hidden">
        <video
          ref={videoRef}
          className="absolute inset-0 w-full h-full object-cover"
          autoPlay
          playsInline
          muted
          width={640}
          height={480}
        />
        <canvas
          ref={canvasRef}
          className="absolute inset-0 z-10 w-full h-full"
          width={640}
          height={480}
        />
        <div className="face-overlay">
          <div className="w-48 h-48 border-2 border-primary rounded-full"></div>
        </div>
        
        {/* Recognition Status */}
        <div className="absolute inset-x-0 bottom-4 flex justify-center items-center">
          <div className="bg-neutral-800/80 text-white text-sm py-1 px-3 rounded-full flex items-center">
            <span>{detectionStatus}</span>
            <div className="ml-2 flex space-x-1">
              <div className="h-2 w-2 bg-primary rounded-full animate-pulse"></div>
              <div className="h-2 w-2 bg-primary rounded-full animate-pulse delay-75"></div>
              <div className="h-2 w-2 bg-primary rounded-full animate-pulse delay-150"></div>
            </div>
          </div>
        </div>
      </div>

      {showRetry && (
        <div className="mt-4 flex justify-center">
          <Button 
            onClick={handleRetry}
            variant="default"
          >
            Retry
          </Button>
        </div>
      )}
    </div>
  );
};

export default FaceRecognition;
