import React from 'react';
import { format } from 'date-fns';

interface Activity {
  id: number;
  userId: number;
  activity: string;
  timestamp: string;
}

interface ActivityListProps {
  activities: Activity[];
  isLoading: boolean;
}

const ActivityList: React.FC<ActivityListProps> = ({ activities, isLoading }) => {
  if (isLoading) {
    return (
      <div className="space-y-3 animate-pulse">
        {[1, 2, 3].map((i) => (
          <div key={i} className="flex items-start py-2 border-b border-neutral-100 last:border-0">
            <div className="w-8 h-8 rounded-full bg-neutral-200 mr-3"></div>
            <div className="flex-1">
              <div className="h-4 bg-neutral-200 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-neutral-200 rounded w-1/2"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (activities.length === 0) {
    return (
      <div className="py-4 text-center text-neutral-500">
        No recent activity found
      </div>
    );
  }

  const getActivityIcon = (activity: string) => {
    if (activity.includes('login')) {
      return <i className="fas fa-sign-in-alt text-sm"></i>;
    } else if (activity.includes('profile') || activity.includes('updated')) {
      return <i className="fas fa-cog text-sm"></i>;
    } else if (activity.includes('created')) {
      return <i className="fas fa-user-plus text-sm"></i>;
    } else {
      return <i className="fas fa-info-circle text-sm"></i>;
    }
  };

  const getActivityColor = (activity: string) => {
    if (activity.includes('login')) {
      return 'bg-primary/10 text-primary';
    } else if (activity.includes('updated') || activity.includes('profile')) {
      return 'bg-neutral-100 text-neutral-600';
    } else if (activity.includes('created')) {
      return 'bg-success/10 text-success';
    } else {
      return 'bg-neutral-100 text-neutral-600';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    
    const isToday = date.getDate() === now.getDate() && 
                    date.getMonth() === now.getMonth() && 
                    date.getFullYear() === now.getFullYear();
    
    const isYesterday = date.getDate() === now.getDate() - 1 && 
                        date.getMonth() === now.getMonth() && 
                        date.getFullYear() === now.getFullYear();
    
    if (isToday) {
      return `Today, ${format(date, 'h:mm a')}`;
    } else if (isYesterday) {
      return `Yesterday, ${format(date, 'h:mm a')}`;
    } else {
      return format(date, 'MMM d, yyyy, h:mm a');
    }
  };

  return (
    <div className="space-y-3">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-start py-2 border-b border-neutral-100 last:border-0">
          <div className={`w-8 h-8 rounded-full ${getActivityColor(activity.activity)} flex items-center justify-center mr-3 mt-0.5`}>
            {getActivityIcon(activity.activity)}
          </div>
          <div>
            <p className="text-sm font-medium text-neutral-800">{activity.activity}</p>
            <p className="text-xs text-neutral-500">{formatDate(activity.timestamp)}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ActivityList;
