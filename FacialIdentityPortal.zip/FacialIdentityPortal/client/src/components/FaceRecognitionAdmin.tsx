import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useFaceRecognition } from '../hooks/use-face-recognition';
import { Download, RefreshCw, Users, Image } from 'lucide-react';

export function FaceRecognitionAdmin() {
  const { knownFaces, isLoading, isReady, error } = useFaceRecognition();
  const [showDetails, setShowDetails] = useState(false);
  
  const downloadFaceData = () => {
    // Create a URL to download the face data
    window.open('/api/download-faces', '_blank');
  };
  
  return (
    <Card className="mb-6">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl flex items-center">
          <Users className="mr-2 h-5 w-5" /> 
          Face Recognition Database
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-4">
              <RefreshCw className="h-5 w-5 animate-spin text-muted-foreground" />
              <span className="ml-2 text-muted-foreground">Loading face data...</span>
            </div>
          ) : error ? (
            <div className="text-red-500">
              Error loading face data: {error}
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Known Faces</h3>
                  <p className="text-sm text-muted-foreground">
                    {knownFaces.length} registered face{knownFaces.length !== 1 ? 's' : ''}
                  </p>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowDetails(prev => !prev)}
                  >
                    {showDetails ? 'Hide Details' : 'Show Details'}
                  </Button>
                  
                  <Button
                    variant="default"
                    size="sm"
                    onClick={downloadFaceData}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Download className="h-4 w-4 mr-1" /> Export Data
                  </Button>
                </div>
              </div>
              
              <Separator />
              
              {knownFaces.length > 0 ? (
                <div className="space-y-3">
                  {knownFaces.map(face => (
                    <div key={face.userId} className="rounded-lg border p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-semibold">
                            {face.name.charAt(0).toUpperCase()}
                          </div>
                          <div className="ml-3">
                            <p className="font-medium">{face.name}</p>
                            <p className="text-sm text-gray-500">@{face.username}</p>
                          </div>
                        </div>
                        <div className="text-sm text-gray-500">
                          {face.descriptors.length} descriptor{face.descriptors.length !== 1 ? 's' : ''}
                        </div>
                      </div>
                      
                      {showDetails && (
                        <div className="mt-3">
                          <Separator className="my-2" />
                          <p className="text-xs text-muted-foreground mb-1">Face descriptor samples (first 10 values):</p>
                          <div className="bg-gray-50 p-2 rounded text-xs font-mono overflow-x-auto">
                            {face.descriptors.map((descriptor, i) => (
                              <div key={i} className="mb-2">
                                <span className="text-gray-500 mr-2">{i + 1}:</span>
                                [{descriptor.slice(0, 10).map(val => val.toFixed(4)).join(', ')}
                                <span className="text-gray-400"> ... {descriptor.length - 10} more</span>]
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">
                  <Image className="h-12 w-12 mx-auto text-gray-300" />
                  <p className="mt-2">No face descriptors found in the database.</p>
                  <p className="text-sm">Register users with face recognition to see them here.</p>
                </div>
              )}
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}