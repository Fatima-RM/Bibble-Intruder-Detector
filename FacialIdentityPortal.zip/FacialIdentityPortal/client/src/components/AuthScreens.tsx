import React, { useState } from 'react';
import HomeScreen from './HomeScreen';
import LoginScreen from './LoginScreen';
import RegisterScreen from './RegisterScreen';
import PasswordLoginScreen from './PasswordLoginScreen';

type AuthScreen = 'home' | 'login' | 'register' | 'passwordLogin';

const AuthScreens: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<AuthScreen>('home');

  const showLoginScreen = () => setCurrentScreen('login');
  const showRegisterScreen = () => setCurrentScreen('register');
  const showPasswordLogin = () => setCurrentScreen('passwordLogin');
  const returnToHome = () => setCurrentScreen('home');

  return (
    <div className="max-w-md mx-auto">
      {currentScreen === 'home' && (
        <HomeScreen 
          onLoginClick={showLoginScreen} 
          onRegisterClick={showRegisterScreen}
        />
      )}
      
      {currentScreen === 'login' && (
        <LoginScreen 
          onCancel={returnToHome} 
          onPasswordLogin={showPasswordLogin}
        />
      )}
      
      {currentScreen === 'register' && (
        <RegisterScreen onCancel={returnToHome} />
      )}
      
      {currentScreen === 'passwordLogin' && (
        <PasswordLoginScreen 
          onCancel={showLoginScreen}
        />
      )}
    </div>
  );
};

export default AuthScreens;
