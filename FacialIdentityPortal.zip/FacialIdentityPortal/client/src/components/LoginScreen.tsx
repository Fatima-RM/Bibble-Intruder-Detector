import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '../context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { loadModels, getFaceDescriptors, descriptorToArray } from '../lib/faceRecognition';
import { speakGreeting, getTimeBasedGreeting, getPersonalizedGreeting } from '../lib/utils';
import { useFaceRecognition } from '../hooks/use-face-recognition';
import { HelpCircle, Camera, KeySquare } from 'lucide-react';

interface LoginScreenProps {
  onCancel: () => void;
  onPasswordLogin: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ 
  onCancel, 
  onPasswordLogin 
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const { login } = useAuth();
  const { toast } = useToast();
  const { isReady, isLoading, error, recognizeFace, getTestUserIfAvailable } = useFaceRecognition();

  const [username, setUsername] = useState('');
  const [recognitionStatus, setRecognitionStatus] = useState('Looking for face...');
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackType, setFeedbackType] = useState<'success' | 'error'>('success');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [showRetry, setShowRetry] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showAccessibility, setShowAccessibility] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    
    async function setupCamera() {
      try {
        await loadModels();
        
        if (videoRef.current) {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'user' },
            audio: false
          });
          
          videoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing camera:', error);
        setFeedbackType('error');
        setFeedbackMessage('Failed to access camera. Please make sure camera permissions are granted.');
        setShowFeedback(true);
      }
    }
    
    setupCamera();
    
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => {
          track.stop();
        });
      }
    };
  }, []);

  // Helper function to announce messages to screen readers
  const announceToScreenReader = (message: string) => {
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'assertive');
    announcement.setAttribute('role', 'status');
    announcement.className = 'sr-only';
    announcement.innerText = message;
    document.body.appendChild(announcement);
    
    // Remove after screen reader has had time to read it
    setTimeout(() => {
      document.body.removeChild(announcement);
    }, 3000);
  };

  const handleRecognition = async () => {
    if (!videoRef.current || isProcessing || !isReady) return;
    
    setIsProcessing(true);
    const detectingStatus = 'Detecting face...';
    setRecognitionStatus(detectingStatus);
    announceToScreenReader(detectingStatus);
    
    try {
      // Try to get a test user if we're in test mode
      const testUser = getTestUserIfAvailable(username);
      
      if (testUser) {
        console.log(`Found test user: ${testUser.name} (${testUser.username})`);
      }
      
      // Use our enhanced recognition system
      const recognitionResult = await recognizeFace(videoRef.current);
      
      if (!recognitionResult.isRecognized) {
        const noFaceStatus = 'No face detected or not recognized. Please position your face in the frame.';
        setRecognitionStatus(noFaceStatus);
        announceToScreenReader(noFaceStatus);
        setIsProcessing(false);
        return;
      }
      
      const analyzingStatus = 'Analyzing features...';
      setRecognitionStatus(analyzingStatus);
      announceToScreenReader(analyzingStatus);
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const matchingStatus = 'Matching identity...';
      setRecognitionStatus(matchingStatus);
      announceToScreenReader(matchingStatus);
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // We've already recognized the face, let's do final server verification
      // Announce that we're verifying the face
      announceToScreenReader("Verifying identity, please wait...");
      
      // Get face descriptor for server verification
      const faceDescriptor = await getFaceDescriptors(videoRef.current);
      
      if (!faceDescriptor) {
        console.error('No face descriptor found. Please ensure your face is clearly visible.');
        setFeedbackType('error');
        setFeedbackMessage('✗ Face detection failed. Please ensure your face is clearly visible and try again.');
        setShowFeedback(true);
        setShowRetry(true);
        announceToScreenReader("Face detection failed. Please position your face clearly in the frame and try again.");
        setIsProcessing(false);
        return;
      }
      
      // Convert descriptor to array for sending to server
      const descriptorArray = descriptorToArray(faceDescriptor);
      
      // For test purposes, log the descriptor length to confirm data is valid
      console.log(`Face descriptor obtained with ${descriptorArray.length} points`);
      
      // If we found a matching face in our local database, use that information
      let result;
      
      // For authorized users, we want to ensure we're using exact usernames
      // This helps prevent login issues due to case sensitivity
      const authorizedUsers = ['fatima', 'usman', 'ahmad'];
      const normalizedUsername = username.toLowerCase().trim();
      const isAuthorizedUser = authorizedUsers.includes(normalizedUsername);
      
      if (isAuthorizedUser) {
        // For our specific authorized users, ensure correct username case
        // fatima → Fatima, usman → Usman, ahmad → Sir Ahmad Nawaz
        let properUsername = username;
        if (normalizedUsername === 'fatima') properUsername = 'Fatima';
        if (normalizedUsername === 'usman') properUsername = 'Usman';
        if (normalizedUsername === 'ahmad') properUsername = 'Sir Ahmad Nawaz';
        
        console.log(`Logging in authorized user: ${properUsername}`);
        
        // Send to server with the proper username
        result = await login({ 
          username: properUsername, 
          faceData: descriptorArray 
        }, 'face');
      } 
      else if (recognitionResult.username) {
        // Override username from input if recognized automatically
        const recognizedUsername = recognitionResult.username;
        
        // Send to server with the recognized username
        result = await login({ 
          username: recognizedUsername, 
          faceData: descriptorArray 
        }, 'face');
        
        // If login succeeded but username doesn't match input, inform the user
        if (result.success && recognizedUsername !== username && username.trim()) {
          console.log(`Username input was ${username} but recognized as ${recognizedUsername}`);
        }
      } else {
        // Fallback to normal login with provided username
        result = await login({ username, faceData: descriptorArray }, 'face');
      }
      
      if (result.success && result.user) {
        setFeedbackType('success');
        setFeedbackMessage('✓ Face recognized! Logging you in...');
        setShowFeedback(true);
        setShowRetry(false);
        
        // Get the user's name
        const userName = result.user.name;
        const userUsername = result.user.username;
        
        // Get a personalized greeting based on the user
        const timeGreeting = getTimeBasedGreeting();
        const personalizedGreeting = getPersonalizedGreeting(userUsername);
        
        // Update UI with recognition success
        const successMessage = `✓ Face recognized! ${timeGreeting}, ${userName}!`;
        setFeedbackMessage(successMessage);
        announceToScreenReader(`Authentication successful. ${personalizedGreeting}`);
        
        // Speech greeting with visual indicator
        setIsSpeaking(true);
        
        // Speak the personalized greeting
        speakGreeting(userName, personalizedGreeting)
          .then(() => {
            setIsSpeaking(false);
          })
          .catch(error => {
            console.error('Speech synthesis error:', error);
            setIsSpeaking(false);
            // If speech fails, announce that speech wasn't available
            announceToScreenReader("Voice greeting unavailable, but login was successful");
          });
        
        toast({
          title: "Login Successful",
          description: personalizedGreeting,
        });
      } else {
        const errorMessage = '✗ Face not recognized. Please try again or use password.';
        setFeedbackType('error');
        setFeedbackMessage(errorMessage);
        setShowFeedback(true);
        setShowRetry(true);
        announceToScreenReader("Authentication failed. Your face was not recognized. You can try again or use your password instead.");
      }
    } catch (error) {
      console.error('Face recognition error:', error);
      const errorMessage = '✗ An error occurred during face recognition. Please try again.';
      setFeedbackType('error');
      setFeedbackMessage(errorMessage);
      setShowFeedback(true);
      setShowRetry(true);
      announceToScreenReader("An error occurred with face recognition. Please try again or use your password instead.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleUsernameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      announceToScreenReader('Starting face recognition process');
      handleRecognition();
    } else {
      const errorMessage = 'Please enter your username first';
      setFeedbackType('error');
      setFeedbackMessage(errorMessage);
      setShowFeedback(true);
      announceToScreenReader(errorMessage);
      
      // Focus the username input field for better accessibility
      const usernameInput = document.getElementById('username');
      if (usernameInput) {
        usernameInput.focus();
      }
    }
  };

  const retryFaceLogin = () => {
    setShowFeedback(false);
    setShowRetry(false);
    setRecognitionStatus('Looking for face...');
    announceToScreenReader('Retrying face recognition. Please position your face in the frame.');
    handleRecognition();
  };
  
  // Set up keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Escape key to cancel
      if (e.key === 'Escape') {
        announceToScreenReader('Cancelling face login');
        onCancel();
      }
      
      // Alt+P for password login
      if (e.altKey && e.key === 'p') {
        announceToScreenReader('Switching to password login');
        onPasswordLogin();
      }
      
      // Alt+A to toggle accessibility info
      if (e.altKey && e.key === 'a') {
        setShowAccessibility(prev => !prev);
        announceToScreenReader(showAccessibility ? 'Hiding accessibility options' : 'Showing accessibility options');
      }
      
      // Alt+R to retry face login when retry button is shown
      if (e.altKey && e.key === 'r' && showRetry) {
        retryFaceLogin();
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onCancel, onPasswordLogin, showRetry, showAccessibility]);

  return (
    <Card className="bg-white rounded-lg shadow-md p-8" role="region" aria-labelledby="login-heading">
      <CardContent className="p-0">
        <div className="text-center mb-4">
          <h2 id="login-heading" className="text-2xl font-bold text-neutral-800">Login with Face ID</h2>
          <p className="text-neutral-600 text-sm mt-1" id="login-description">
            Position your face in the frame for verification
          </p>
          
          <Button
            variant="ghost"
            size="sm"
            className="mt-2"
            onClick={() => {
              setShowAccessibility(prev => !prev);
              announceToScreenReader(showAccessibility ? "Hiding accessibility options" : "Showing accessibility options");
            }}
            aria-expanded={showAccessibility}
            aria-controls="accessibility-panel"
          >
            <HelpCircle className="h-4 w-4 mr-1" />
            {showAccessibility ? "Hide Accessibility Options" : "Accessibility Options"}
          </Button>
        </div>
        
        {showAccessibility && (
          <div 
            id="accessibility-panel"
            className="bg-blue-50 p-3 rounded-md mb-4 text-xs border border-blue-200"
            role="region"
            aria-labelledby="accessibility-title"
          >
            <h3 id="accessibility-title" className="font-semibold text-blue-800 mb-1">Keyboard Shortcuts:</h3>
            <ul className="text-blue-700 space-y-1 pl-2">
              <li><span className="font-mono bg-white px-1 rounded">Esc</span> - Cancel and return to home</li>
              <li><span className="font-mono bg-white px-1 rounded">Alt+P</span> - Switch to password login</li>
              <li><span className="font-mono bg-white px-1 rounded">Alt+A</span> - Toggle this accessibility panel</li>
              <li><span className="font-mono bg-white px-1 rounded">Alt+R</span> - Retry face detection (when retry is available)</li>
              <li><span className="font-mono bg-white px-1 rounded">Tab</span> - Navigate between controls</li>
              <li><span className="font-mono bg-white px-1 rounded">Space/Enter</span> - Activate focused buttons</li>
            </ul>
            <p className="mt-2 text-blue-600">
              <span className="font-semibold">Audio features:</span> Voice greeting on successful login, 
              screen reader announcements for status changes, and audio feedback for important events.
            </p>
          </div>
        )}
        
        <div className="mb-4">
          <label htmlFor="username" className="block text-sm font-medium text-neutral-700 mb-1">Username</label>
          <input 
            type="text" 
            id="username" 
            className="block w-full rounded-md border-neutral-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
            placeholder="Enter your username" 
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            aria-required="true"
            aria-describedby="username-hint"
          />
          <p id="username-hint" className="text-xs text-neutral-500 mt-1">
            Enter your registered username to verify your identity
          </p>
        </div>
        
        <div className="relative mb-6" aria-live="polite" aria-atomic="true">
          <div 
            className="aspect-w-16 aspect-h-9 bg-neutral-200 rounded-lg overflow-hidden relative"
            role="application" 
            aria-label="Face recognition camera"
            style={{ maxWidth: "800px", margin: "0 auto" }}
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-full max-w-md text-center">
                <div className="mb-2 text-blue-600">
                  <div className="inline-block p-2 rounded-full bg-blue-50/70">
                    <span className="block w-40 h-40 rounded-full border-4 border-dashed border-blue-400"></span>
                  </div>
                </div>
                <p className="text-sm text-white bg-gray-800/70 px-4 py-2 rounded-full inline-block">Position your face within the circle</p>
              </div>
            </div>
            
            <video 
              ref={videoRef} 
              className="object-cover w-full h-full" 
              autoPlay 
              muted 
              playsInline
              aria-hidden="true" // Hide from screen readers as status is announced separately
            ></video>
            
            {/* Feedback overlay */}
            {showFeedback && (
              <div
                className={`absolute inset-0 flex items-center justify-center ${
                  feedbackType === 'success' ? 'bg-green-600/70' : 'bg-red-600/70'
                }`}
                role="status"
                aria-live="assertive"
              >
                <div className="text-white text-center p-4">
                  <p className="text-2xl font-bold">{feedbackMessage}</p>
                  {isSpeaking && (
                    <p className="text-sm mt-2 animate-pulse">
                      <span className="inline-block mr-1">🔊</span> Speaking greeting...
                    </p>
                  )}
                  {showRetry && (
                    <Button 
                      className="mt-4 bg-white text-red-600 hover:bg-white/90"
                      onClick={retryFaceLogin}
                      aria-label="Retry face recognition"
                    >
                      <Camera className="w-4 h-4 mr-2" />
                      Retry
                    </Button>
                  )}
                </div>
              </div>
            )}
            
            {/* Recognition status */}
            <div 
              className="absolute inset-x-0 bottom-4 flex justify-center items-center"
              role="status"
              aria-live="polite"
            >
              <div className={`px-3 py-1 rounded-full ${
                showFeedback ? 'opacity-0' : 'opacity-100 bg-gray-900/70'
              } transition-opacity duration-200`}>
                <p className="text-white text-sm">
                  {isProcessing ? (
                    <span className="flex items-center">
                      <span className="animate-pulse mr-2">●</span>
                      {recognitionStatus}
                    </span>
                  ) : (
                    recognitionStatus
                  )}
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <form ref={formRef} onSubmit={handleUsernameSubmit} className="flex flex-col space-y-4">
          <div className="flex justify-between space-x-2">
            <Button 
              variant="outline" 
              type="button" 
              onClick={onCancel}
              className="flex-1"
              aria-label="Cancel and return to home screen"
            >
              Cancel
            </Button>
            <Button 
              variant="default" 
              type="submit" 
              disabled={isProcessing}
              className="flex-1 bg-gradient-to-r from-blue-600 to-blue-700"
              aria-label="Verify face and login"
            >
              {isProcessing ? 'Processing...' : 'Verify Face'}
            </Button>
          </div>
          
          <Button 
            variant="ghost" 
            type="button" 
            onClick={onPasswordLogin}
            className="text-sm flex items-center justify-center text-blue-600 hover:text-blue-700"
            aria-label="Switch to password login instead"
          >
            <KeySquare className="w-4 h-4 mr-2" />
            Use Password Instead
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default LoginScreen;