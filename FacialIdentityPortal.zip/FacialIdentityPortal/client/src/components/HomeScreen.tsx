import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface HomeScreenProps {
  onLoginClick: () => void;
  onRegisterClick: () => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ 
  onLoginClick, 
  onRegisterClick 
}) => {
  return (
    <Card className="bg-white rounded-lg shadow-md p-8 text-center">
      <CardContent className="p-0">
        <div className="mb-8">
          <i className="fas fa-user-shield text-primary text-5xl mb-4"></i>
          <h2 className="text-2xl font-bold text-neutral-800 mb-2">Facial Recognition Authentication</h2>
          <p className="text-neutral-600">Securely login with your face</p>
        </div>
        <div className="space-y-4">
          <Button 
            className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-3 px-4 rounded-md transition flex items-center justify-center" 
            onClick={onLoginClick}
          >
            <i className="fas fa-camera mr-2"></i> Login with Face ID
          </Button>
          
          <Button 
            variant="outline"
            className="w-full hover:bg-neutral-100 text-primary border border-primary font-medium py-3 px-4 rounded-md transition flex items-center justify-center" 
            onClick={onRegisterClick}
          >
            <i className="fas fa-user-plus mr-2"></i> Register New Face
          </Button>
          
          <p className="text-xs text-neutral-500 mt-4">
            We use secure face-api.js technology to protect your biometric data.
            Your face data never leaves your device.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default HomeScreen;
