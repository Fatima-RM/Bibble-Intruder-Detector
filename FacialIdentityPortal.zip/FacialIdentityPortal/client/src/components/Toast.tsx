import React, { useState, useEffect } from 'react';

interface ToastProps {
  title: string;
  message: string;
  type: 'success' | 'error';
  duration?: number;
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ 
  title, 
  message, 
  type, 
  duration = 3000, 
  onClose 
}) => {
  const [isVisible, setIsVisible] = useState(true);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onClose, 300); // Wait for fade out animation
    }, duration);
    
    return () => clearTimeout(timer);
  }, [duration, onClose]);

  return (
    <div 
      className={`bg-white shadow-lg rounded-lg max-w-md w-full p-4 border-l-4 
        ${type === 'success' ? 'border-success' : 'border-error'}
        flex items-start transform transition-all duration-300
        ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}
    >
      <div className="flex-shrink-0 mr-3">
        <div className={`w-8 h-8 rounded-full 
          ${type === 'success' ? 'bg-success/10' : 'bg-error/10'} 
          flex items-center justify-center`}>
          <i className={`fas ${type === 'success' ? 'fa-check-circle text-success' : 'fa-exclamation-circle text-error'}`}></i>
        </div>
      </div>
      <div className="flex-1">
        <h4 className="text-sm font-medium text-neutral-800">{title}</h4>
        <p className="text-xs text-neutral-600 mt-0.5">{message}</p>
      </div>
      <button 
        className="ml-4 text-neutral-400 hover:text-neutral-500"
        onClick={() => {
          setIsVisible(false);
          setTimeout(onClose, 300);
        }}
      >
        <i className="fas fa-times"></i>
      </button>
    </div>
  );
};

export default Toast;
