import { LogOut } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

export default function AuthStatus() {
  const { isAuthenticated, user, logout } = useAuth();

  if (!isAuthenticated || !user) {
    return (
      <div className="flex items-center">
        <span className="text-neutral-600 mr-4">Secure Facial Authentication</span>
      </div>
    );
  }

  return (
    <div className="flex items-center">
      <span className="text-neutral-600 mr-4">{user.name}</span>
      <Avatar className="h-8 w-8">
        <AvatarImage src={user.faceDataUrl} alt={user.name} />
        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
      </Avatar>
      <Button
        variant="ghost"
        size="sm"
        className="ml-4 text-sm text-neutral-600 hover:text-primary"
        onClick={logout}
      >
        <LogOut className="h-4 w-4 mr-1" />
        Logout
      </Button>
    </div>
  );
}
