import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/button';
import { useToast } from '@/hooks/use-toast';

const Header: React.FC = () => {
  const { isAuthenticated, user, logout } = useAuth();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to log out. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <div className="text-primary text-3xl mr-3">👤</div>
          <h1 className="text-2xl font-bold text-neutral-800">FaceID</h1>
        </div>

        <div className="auth-status">
          {!isAuthenticated ? (
            <div className="flex items-center">
              <span className="text-neutral-600 mr-4">Secure Facial Authentication</span>
            </div>
          ) : (
            <div className="flex items-center">
              <span className="text-neutral-600 mr-4">{user?.name}</span>
              <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center">
                {user?.name.charAt(0).toUpperCase()}
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleLogout}
                className="ml-4 text-sm text-neutral-600 hover:text-primary transition"
              >
                Logout
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
