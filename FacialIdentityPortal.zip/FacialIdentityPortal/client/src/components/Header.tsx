import { Link } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import AuthStatus from "./AuthStatus";
import { ShieldX } from "lucide-react";

export default function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <ShieldX className="text-primary h-8 w-8 mr-3" />
          <Link href="/">
            <a className="text-2xl font-bold text-neutral-800">FaceID</a>
          </Link>
        </div>
        <AuthStatus />
      </div>
    </header>
  );
}
