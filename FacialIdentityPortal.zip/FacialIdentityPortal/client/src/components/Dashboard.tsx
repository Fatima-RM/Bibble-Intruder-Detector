import React, { useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import UserTable from './UserTable';
import ActivityList from './ActivityList';
import { FaceRecognitionAdmin } from './FaceRecognitionAdmin';
import { useQuery } from '@tanstack/react-query';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { apiRequest } from '@/lib/queryClient';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  const { data: activities, isLoading: activitiesLoading } = useQuery({
    queryKey: [user ? `/api/users/${user.id}/activities` : null],
    enabled: !!user
  });

  const { data: users, isLoading: usersLoading } = useQuery({
    queryKey: ['/api/users']
  });

  const updateUserSettings = async (setting: string, value: boolean) => {
    if (!user) return;
    
    try {
      await apiRequest('PUT', `/api/users/${user.id}`, {
        [setting]: value
      });
    } catch (error) {
      console.error('Failed to update settings:', error);
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-neutral-800 mb-2">Welcome, {user?.name}!</h2>
        <p className="text-neutral-600">You've been authenticated using facial recognition.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Account Card */}
        <Card className="col-span-1">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-semibold text-neutral-800">Your Account</h3>
              <i className="fas fa-user-circle text-primary text-lg"></i>
            </div>
            
            <div className="flex items-center mb-5">
              <div className="h-16 w-16 rounded-full bg-primary/20 text-primary flex items-center justify-center text-2xl font-semibold">
                {user?.name.charAt(0).toUpperCase()}
              </div>
              <div className="ml-4">
                <h4 className="font-medium text-neutral-800">{user?.name}</h4>
                <p className="text-sm text-neutral-600">{user?.email}</p>
                <span className="inline-flex items-center px-2 py-0.5 mt-1 rounded text-xs font-medium bg-green-100 text-green-800">
                  <i className="fas fa-check-circle mr-1"></i> Face ID Active
                </span>
              </div>
            </div>
            
            <div className="space-y-2">
              <button className="w-full bg-white border border-neutral-300 text-neutral-700 hover:bg-neutral-50 text-sm font-medium py-2 px-4 rounded-md transition flex items-center justify-center">
                <i className="fas fa-pencil-alt mr-2"></i> Edit Profile
              </button>
              <button className="w-full bg-white border border-neutral-300 text-neutral-700 hover:bg-neutral-50 text-sm font-medium py-2 px-4 rounded-md transition flex items-center justify-center">
                <i className="fas fa-camera mr-2"></i> Update Face Data
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Security Card */}
        <Card className="col-span-1">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-semibold text-neutral-800">Security Settings</h3>
              <i className="fas fa-shield-alt text-primary text-lg"></i>
            </div>
            
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-neutral-700">Face ID Authentication</span>
                  <Switch 
                    id="faceIdToggle" 
                    checked={user?.faceIdEnabled} 
                    onCheckedChange={(checked) => updateUserSettings('faceIdEnabled', checked)}
                  />
                </div>
                <p className="text-xs text-neutral-500">Enable or disable facial recognition login</p>
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-neutral-700">Fallback Password Login</span>
                  <Switch 
                    id="passwordToggle" 
                    checked={user?.passwordEnabled} 
                    onCheckedChange={(checked) => updateUserSettings('passwordEnabled', checked)}
                  />
                </div>
                <p className="text-xs text-neutral-500">Allow login with username and password</p>
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-neutral-700">Two-Factor Authentication</span>
                  <Switch id="twoFactorToggle" />
                </div>
                <p className="text-xs text-neutral-500">Require a second verification method</p>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-neutral-200">
              <button className="w-full bg-white border border-neutral-300 text-neutral-700 hover:bg-neutral-50 text-sm font-medium py-2 px-4 rounded-md transition flex items-center justify-center">
                <i className="fas fa-key mr-2"></i> Change Password
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Activity Card */}
        <Card className="col-span-1">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-semibold text-neutral-800">Recent Activity</h3>
              <i className="fas fa-clock text-primary text-lg"></i>
            </div>
            
            <ActivityList 
              activities={activities?.activities || []} 
              isLoading={activitiesLoading} 
            />
            
            <div className="mt-4">
              <button className="w-full bg-white border border-neutral-300 text-neutral-700 hover:bg-neutral-50 text-sm font-medium py-2 px-4 rounded-md transition flex items-center justify-center">
                <i className="fas fa-list mr-2"></i> View All Activity
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Face Recognition Admin Section */}
      <div className="mt-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-neutral-800">Face Recognition</h3>
        </div>
        
        <FaceRecognitionAdmin />
      </div>
        
      {/* User Management Section */}
      <div className="mt-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-neutral-800">User Management</h3>
          <button className="bg-primary hover:bg-primary/90 text-white text-sm font-medium py-2 px-4 rounded-md transition flex items-center">
            <i className="fas fa-user-plus mr-2"></i> Add New User
          </button>
        </div>
        
        <UserTable users={users?.users || []} isLoading={usersLoading} />
      </div>
    </div>
  );
};

export default Dashboard;
