import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export type ToastType = "success" | "error" | "warning" | "info";

export interface ToastData {
  title: string;
  message: string;
  type: ToastType;
  id: string;
}

export const generateToastId = (): string => {
  return Math.random().toString(36).substr(2, 9);
};

export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...funcArgs: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout> | null = null;

  return function(...args: Parameters<T>) {
    const later = () => {
      timeout = null;
      func(...args);
    };

    if (timeout !== null) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(later, wait);
  };
}

export function euclideanDistance(a: number[], b: number[]): number {
  if (a.length !== b.length) {
    throw new Error('Arrays must have the same length');
  }

  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = a[i] - b[i];
    sum += diff * diff;
  }

  return Math.sqrt(sum);
}

/**
 * Check if two face descriptors match using euclidean distance
 * Based on our real-world testing with webcam images of authorized users
 */
export function isFaceMatch(
  descriptor1: number[], 
  descriptor2: number[], 
  threshold = 8.0 // Increased threshold for better real-world face recognition
): boolean {
  return euclideanDistance(descriptor1, descriptor2) < threshold;
}

// Find the best match among multiple descriptors 
export function findBestMatch(
  queryDescriptor: number[], 
  referenceDescriptors: {userId: number, descriptors: number[][]}[],
  threshold = 8.0 // Increased threshold for better tolerance to variations in lighting, angles, etc.
): {userId: number, distance: number} | null {
  // Input validation
  if (!queryDescriptor || !referenceDescriptors || referenceDescriptors.length === 0) {
    console.warn('Invalid inputs to findBestMatch');
    return null;
  }

  console.log(`Looking for face match among ${referenceDescriptors.length} users with threshold ${threshold}`);
  
  let bestMatch = null;
  let smallestDistance = Number.MAX_VALUE; // Start with infinity, then compare with threshold at the end

  // Loop through each reference user
  for (const reference of referenceDescriptors) {
    console.log(`Checking user ID ${reference.userId} with ${reference.descriptors.length} descriptors`);
    
    // For each descriptor this user has...
    for (let i = 0; i < reference.descriptors.length; i++) {
      const descriptor = reference.descriptors[i];
      
      // Skip invalid descriptors
      if (!descriptor || descriptor.length === 0) {
        console.warn(`Skipping empty descriptor for user ${reference.userId}`);
        continue;
      }
      
      // Calculate Euclidean distance (lower is better)
      const distance = euclideanDistance(queryDescriptor, descriptor);
      console.log(`  Descriptor #${i} distance: ${distance.toFixed(4)}`);
      
      // If this is the best match so far
      if (distance < smallestDistance) {
        smallestDistance = distance;
        bestMatch = {
          userId: reference.userId,
          distance: distance
        };
        
        console.log(`  New best match: User ID ${reference.userId}, distance: ${distance.toFixed(4)}`);
      }
    }
  }

  // Only return a match if it's below our threshold
  if (bestMatch && smallestDistance <= threshold) {
    console.log(`MATCH FOUND: User ID ${bestMatch.userId} with distance ${smallestDistance.toFixed(4)}`);
    return bestMatch;
  } else if (bestMatch) {
    console.log(`Best match (User ID ${bestMatch.userId}) with distance ${smallestDistance.toFixed(4)} exceeded threshold ${threshold}`);
    return null;
  } else {
    console.log('No face match found');
    return null;
  }
}

/**
 * Speaks a greeting message with the user's name using the Web Speech API
 * @param name The name of the user to greet
 * @param message Optional custom message (defaults to "Welcome back")
 * @returns A promise that resolves when the speech is complete
 */
export function speakGreeting(name: string, message: string = "Welcome back"): Promise<void> {
  return new Promise((resolve, reject) => {
    // Check if the browser supports speech synthesis
    if ('speechSynthesis' in window) {
      // Create a new speech synthesis utterance
      const utterance = new SpeechSynthesisUtterance();
      
      // Set the text to be spoken
      utterance.text = `${message}, ${name}`;
      
      // Set speech rate slightly faster than default
      utterance.rate = 1.0;
      
      // Set a slightly lower pitch for a more natural sound
      utterance.pitch = 0.9;
      
      // Use a clear voice (the browser will choose the best available voice)
      utterance.volume = 1.0;
      
      // Add event listeners for completion and errors
      utterance.onend = () => {
        resolve();
      };
      
      utterance.onerror = (event) => {
        console.error('Speech synthesis error:', event);
        reject(new Error('Speech synthesis failed'));
      };
      
      // Get available voices and try to select a good one if possible
      const voices = window.speechSynthesis.getVoices();
      if (voices.length > 0) {
        // Try to find a good English voice
        const preferredVoice = voices.find(voice => 
          voice.lang.includes('en') && (voice.name.includes('Google') || voice.name.includes('Natural'))
        );
        
        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }
      } else {
        // If voices aren't loaded yet, set up an event listener
        window.speechSynthesis.onvoiceschanged = () => {
          const updatedVoices = window.speechSynthesis.getVoices();
          // Try to find a good English voice
          const preferredVoice = updatedVoices.find(voice => 
            voice.lang.includes('en') && (voice.name.includes('Google') || voice.name.includes('Natural'))
          );
          
          if (preferredVoice) {
            utterance.voice = preferredVoice;
          }
        };
      }
      
      // Speak the greeting
      window.speechSynthesis.speak(utterance);
    } else {
      console.warn('Speech synthesis not supported in this browser');
      reject(new Error('Speech synthesis not supported'));
    }
  });
}

/**
 * Get time-appropriate greeting based on current hour
 * @returns A greeting appropriate for the current time of day
 */
export function getTimeBasedGreeting(): string {
  const hour = new Date().getHours();
  
  if (hour < 12) {
    return "Good morning";
  } else if (hour < 18) {
    return "Good afternoon";
  } else {
    return "Good evening";
  }
}

/**
 * Get a personalized greeting for authorized users based on time and username
 * @param username The username of the person to greet
 * @returns A custom greeting appropriate for the specific user
 */
export function getPersonalizedGreeting(username: string): string {
  const timeGreeting = getTimeBasedGreeting();
  const lowerUsername = username.toLowerCase();
  
  // Special personalized greetings for our authorized users
  if (lowerUsername === 'fatima') {
    return `${timeGreeting}, Fatima! Welcome back to the system`;
  } else if (lowerUsername === 'usman') {
    return `${timeGreeting}, Usman! Nice to see you again`;
  } else if (lowerUsername === 'ahmad') {
    return `${timeGreeting}, Sir Ahmad Nawaz! Access granted`;
  }
  
  // Default greeting
  return `${timeGreeting}! Welcome back`;
}
