import * as faceapi from 'face-api.js';
import { useCallback, useEffect, useState } from 'react';

let modelsLoaded = false;
let faceDetector: faceapi.TinyFaceDetectorOptions;
let faceMatcher: faceapi.FaceMatcher | null = null;

// Custom hook for face detection
export function useFaceDetection({
  videoElement,
  onFaceDetectionResult,
}: {
  videoElement: HTMLVideoElement | null;
  onFaceDetectionResult?: (result: { faceDetected: boolean; faceDescriptor?: Float32Array } | null) => void;
}) {
  const [error, setError] = useState<string | null>(null);

  const startVideo = useCallback(async () => {
    if (!videoElement) {
      console.error("No video element provided");
      return;
    }

    try {
      console.log("Starting video in faceRecognition.ts...");
      
      // First load the face recognition models
      if (!modelsLoaded) {
        console.log("Loading face models before starting video...");
        try {
          await loadModels();
          console.log("Models loaded successfully");
        } catch (modelErr) {
          console.error("Error loading models:", modelErr);
          // Continue anyway, as some browsers might have models cached
        }
      }

      // Try different constraints to maximize compatibility across browsers
      const constraintOptions = [
        // First try with ideal dimensions and user facing
        {
          video: {
            width: { ideal: 640 },
            height: { ideal: 480 },
            facingMode: "user",
          },
          audio: false,
        },
        // Then try with just user facing
        {
          video: { facingMode: "user" },
          audio: false,
        },
        // Finally try with just video enabled
        { video: true, audio: false }
      ];
      
      let stream = null;
      let successConstraint = null;
      let lastError = null;
      
      // Try each constraint until one works
      for (const constraints of constraintOptions) {
        if (stream) break;
        
        try {
          console.log("Trying camera constraints:", constraints);
          stream = await navigator.mediaDevices.getUserMedia(constraints);
          successConstraint = constraints;
          console.log("Camera access successful with constraints:", constraints);
        } catch (err) {
          lastError = err;
          console.warn("Failed with constraints:", constraints, err);
        }
      }
      
      if (!stream) {
        console.error("All camera access attempts failed. Last error:", lastError);
        setError("Could not access camera. Please ensure camera permissions are granted.");
        throw lastError || new Error("Failed to access camera with all constraint options");
      }
      
      // We got a stream, attach it to the video element
      videoElement.srcObject = stream;
      console.log("Stream attached to video element:", stream);
      
      // Return a promise that resolves when the video metadata is loaded
      return new Promise<void>((resolve, reject) => {
        videoElement.onloadedmetadata = () => {
          console.log("Video metadata loaded, starting playback");
          videoElement.play()
            .then(() => {
              console.log("Video playing successfully");
              resolve();
            })
            .catch(playErr => {
              console.error("Error starting video playback:", playErr);
              reject(playErr);
            });
        };
        
        videoElement.onerror = (e) => {
          console.error("Video element error:", e);
          reject(new Error("Video element error"));
        };
        
        // Add a backup timeout to resolve anyway if metadata doesn't load
        setTimeout(() => {
          if (videoElement.readyState === 0) {
            console.warn("Video metadata load timed out, forcing playback");
            try {
              videoElement.play();
              resolve();
            } catch (e) {
              reject(e);
            }
          }
        }, 3000);
      });
    } catch (err) {
      console.error("Error accessing camera:", err);
      setError("Could not access camera. Please ensure camera permissions are granted.");
      throw err;
    }
  }, [videoElement]);

  const stopVideo = useCallback(() => {
    if (!videoElement) return;

    const stream = videoElement.srcObject as MediaStream;
    if (stream) {
      const tracks = stream.getTracks();
      tracks.forEach((track) => track.stop());
      videoElement.srcObject = null;
    }
  }, [videoElement]);

  const detectFace = useCallback(async () => {
    if (!videoElement || !modelsLoaded) return null;

    try {
      // Use getFaceDescriptors which correctly extracts the descriptor
      const descriptor = await getFaceDescriptors(videoElement);
      
      if (descriptor) {
        const result = {
          faceDetected: true,
          faceDescriptor: descriptor,
        };
        
        onFaceDetectionResult?.(result);
        return result;
      } else {
        onFaceDetectionResult?.({ faceDetected: false });
        return { faceDetected: false };
      }
    } catch (err) {
      console.error("Face recognition error:", err);
      onFaceDetectionResult?.(null);
      return null;
    }
  }, [videoElement, onFaceDetectionResult]);

  useEffect(() => {
    return () => {
      // Clean up camera when component unmounts
      stopVideo();
    };
  }, [stopVideo]);

  return {
    startVideo,
    stopVideo,
    detectFace,
    error,
  };
}

/**
 * Loads all required face-api.js models needed for face detection and recognition
 * Uses a more reliable approach with retries and proper error handling
 */
export async function loadModels() {
  if (modelsLoaded) {
    console.log("Models already loaded, skipping load");
    return;
  }
  
  // Use a larger input size for better accuracy with webcam feeds
  const MODEL_SIZE = 320;
  
  // We'll use the CDN source directly
  const modelUrl = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model';
  
  const MAX_RETRIES = 2;
  
  async function loadWithRetry(modelLoader: Promise<void>, name: string): Promise<void> {
    let attempts = 0;
    
    while (attempts < MAX_RETRIES) {
      try {
        await modelLoader;
        console.log(`✓ ${name} loaded successfully`);
        return;
      } catch (error) {
        attempts++;
        if (attempts >= MAX_RETRIES) {
          console.error(`Failed to load ${name} after ${MAX_RETRIES} attempts`);
          throw error;
        }
        console.warn(`Retrying ${name} load, attempt ${attempts+1}...`);
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
  }
  
  try {
    console.log("Loading face-api.js models...");
    console.log(`Loading face models from: ${modelUrl}`);
    
    // Load all required models with retries
    // Load in sequence to prevent race conditions
    
    // 1. First TinyFaceDetector (faster detector)
    await loadWithRetry(faceapi.nets.tinyFaceDetector.loadFromUri(modelUrl), "TinyFaceDetector");
    console.log("✓ TinyFaceDetector loaded - uses less CPU");
    
    // 2. Then FaceRecognitionNet (required for recognition)
    await loadWithRetry(faceapi.nets.faceRecognitionNet.loadFromUri(modelUrl), "FaceRecognitionNet");
    console.log("✓ FaceRecognitionNet loaded - enables recognition");
    
    // 3. Finally FaceLandmark68Net (required for landmarks)
    await loadWithRetry(faceapi.nets.faceLandmark68Net.loadFromUri(modelUrl), "FaceLandmark68Net");
    console.log("✓ FaceLandmark68Net loaded - required for face analysis");
    
    console.log(`All face models successfully loaded from ${modelUrl}`);
    
    // Create face detector with optimized settings for webcam detection
    faceDetector = new faceapi.TinyFaceDetectorOptions({ 
      inputSize: MODEL_SIZE,   // Larger size for better accuracy with webcams
      scoreThreshold: 0.3      // Lower threshold to detect faces more easily
    });
    
    console.log("Face detection models loaded successfully!");
    modelsLoaded = true;
    
    // Warm up the detector to improve first detection speed
    try {
      console.log("Warming up face detector...");
      const canvas = document.createElement('canvas');
      canvas.width = 100;
      canvas.height = 100;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = "#CCCCCC";
        ctx.fillRect(0, 0, 100, 100);
        // Draw a simple face-like shape for warmup
        ctx.fillStyle = "#666666";
        ctx.beginPath();
        ctx.arc(50, 50, 30, 0, Math.PI * 2);
        ctx.fill();
        
        await faceapi.detectSingleFace(canvas, faceDetector);
        console.log("Face detector warmed up");
      }
    } catch (e) {
      console.log("Warm-up detection failed, but we can continue");
    }
    
  } catch (error) {
    console.error('Failed to load face-api models:', error);
    modelsLoaded = false; // Reset so we can try again later
    throw new Error('Could not load face detection models. Please check your internet connection or try a different browser.');
  }
}

// Keep track of last detection time to throttle detections
let lastDetectionTime = 0;
const DETECTION_THROTTLE_MS = 200; // Don't run detection more than once per 200ms

/**
 * Optimized face detection that uses a single API call and throttling for better performance
 */
export async function detectFaces(video: HTMLVideoElement): Promise<faceapi.WithFaceDescriptor<faceapi.WithFaceLandmarks<faceapi.WithFaceDetection<{}>>>[]> {
  // Throttle detections to save CPU
  const now = Date.now();
  if (now - lastDetectionTime < DETECTION_THROTTLE_MS) {
    return []; // Skip this detection cycle if we ran one too recently
  }
  lastDetectionTime = now;
  
  if (!modelsLoaded) {
    console.log("Models not loaded, loading now before detecting faces...");
    try {
      await loadModels();
    } catch (e) {
      console.error("Failed to load models for face detection:", e);
      return [];
    }
  }
  
  if (!video) {
    console.error("No video element provided for face detection");
    return [];
  }
  
  if (video.readyState === 0) {
    console.warn("Video not ready for face detection");
    return [];
  }
  
  try {
    // Make sure face detector exists with optimized settings
    if (!faceDetector) {
      console.log("Creating optimized face detector...");
      // Use settings optimized for webcam face detection
      faceDetector = new faceapi.TinyFaceDetectorOptions({ 
        inputSize: 320,      // Larger size for better accuracy with webcams
        scoreThreshold: 0.3  // Even lower threshold to detect faces more easily
      });
    }
    
    // Check if video is actually playing
    if (video.paused || video.ended) {
      console.warn("Video is paused or ended, cannot detect faces");
      return [];
    }
    
    // Single combined API call is more efficient
    console.time("faceDetection");
    
    // Instead of the two-step process, use a more direct approach
    // Detect faces, get landmarks and descriptors all in one go
    // This approach is more reliable for our specific application
    const fullDetections = await faceapi.detectAllFaces(video, faceDetector)
        .withFaceLandmarks()
        .withFaceDescriptors();
    
    // Log whether we found faces
    if (fullDetections.length === 0) {
      console.log("No faces detected in video");
    } else {
      console.log(`Detected ${fullDetections.length} face(s) with descriptors`);
      
      // Log more details about the detections
      fullDetections.forEach((detection, i) => {
        const { x, y, width, height } = detection.detection.box;
        const confidence = detection.detection.score;
        console.log(`Face #${i+1}: confidence ${(confidence*100).toFixed(1)}%, box: (${x.toFixed(0)},${y.toFixed(0)}) ${width.toFixed(0)}x${height.toFixed(0)}`);
      });
    }
    
    console.timeEnd("faceDetection");
    return fullDetections;
  } catch (error) {
    console.error('Error detecting faces:', error);
    return [];
  }
}

export async function getFaceDescriptors(video: HTMLVideoElement): Promise<Float32Array | null> {
  if (!video) {
    console.error("No video element provided for face descriptor extraction");
    return null;
  }
  
  try {
    console.log("Getting face descriptors...");
    const detections = await detectFaces(video);
    
    if (!detections || detections.length === 0) {
      console.log("No faces detected for descriptor extraction");
      return null;
    }
    
    console.log(`Found ${detections.length} face(s), using the first one`);
    
    // Ensure the descriptor exists
    if (!detections[0].descriptor) {
      console.error("Face detected but no descriptor available");
      return null;
    }
    
    // Use the first face detected
    return detections[0].descriptor;
  } catch (error) {
    console.error("Error getting face descriptors:", error);
    return null;
  }
}

export function createFaceMatcher(faceDescriptor: Float32Array, label: string) {
  const labeledDescriptors = [
    new faceapi.LabeledFaceDescriptors(label, [faceDescriptor])
  ];
  
  faceMatcher = new faceapi.FaceMatcher(labeledDescriptors);
  return faceMatcher;
}

export async function matchFace(video: HTMLVideoElement): Promise<{ isMatch: boolean, label?: string }> {
  if (!faceMatcher) {
    throw new Error('Face matcher not initialized');
  }
  
  const descriptor = await getFaceDescriptors(video);
  
  if (!descriptor) {
    return { isMatch: false };
  }
  
  const match = faceMatcher.findBestMatch(descriptor);
  
  return {
    isMatch: match.distance < 5.0, // Updated threshold for match confidence
    label: match.label
  };
}

export function setFaceMatcherFromDescriptor(storedDescriptor: number[], label: string) {
  const descriptor = new Float32Array(storedDescriptor);
  createFaceMatcher(descriptor, label);
}

// Helper function to draw face detection results on a canvas
export function drawFaceDetections(
  canvas: HTMLCanvasElement,
  video: HTMLVideoElement,
  detections: faceapi.WithFaceLandmarks<WithFaceDetection<{}>>[]
) {
  const displaySize = { width: video.width, height: video.height };
  faceapi.matchDimensions(canvas, displaySize);
  
  const resizedDetections = faceapi.resizeResults(detections, displaySize);
  
  canvas.getContext('2d')?.clearRect(0, 0, canvas.width, canvas.height);
  
  faceapi.draw.drawDetections(canvas, resizedDetections);
  faceapi.draw.drawFaceLandmarks(canvas, resizedDetections);
}

// Helper to convert between Float32Array and regular arrays for storage
export function descriptorToArray(descriptor: Float32Array): number[] {
  return Array.from(descriptor);
}

export function arrayToDescriptor(array: number[]): Float32Array {
  return new Float32Array(array);
}

// Type definition from face-api.js
type WithFaceDetection<T> = T & {
  detection: faceapi.FaceDetection;
};
