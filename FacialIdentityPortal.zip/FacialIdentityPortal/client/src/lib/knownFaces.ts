// Storage for known face descriptors that can be used for authentication
import { arrayToDescriptor } from './faceRecognition';

export interface KnownFace {
  userId: number;
  username: string;
  name: string;
  descriptors: number[][];  // Can store multiple descriptors per user for better recognition
}

// This will be our in-memory cache of known faces
// In a real app, these would be stored in the database
let knownFaces: KnownFace[] = [
  // Default system admin for testing  
  {
    userId: 1,
    username: 'admin',
    name: 'Administrator',
    descriptors: []
  }
];

/**
 * Add a face descriptor for a known user
 */
export function addKnownFace(userId: number, username: string, name: string, descriptor: number[]): void {
  // Check if user already exists
  const existingUser = knownFaces.find(face => face.userId === userId);
  
  if (existingUser) {
    // Add this descriptor to their existing descriptors
    existingUser.descriptors.push(descriptor);
    console.log(`Added new descriptor for user ${username} (${name})`);
  } else {
    // Create a new user entry
    knownFaces.push({
      userId,
      username,
      name,
      descriptors: [descriptor]
    });
    console.log(`Added new user ${username} (${name}) with face descriptor`);
  }
}

/**
 * Get all known face descriptors for matching
 */
export function getKnownFaces(): KnownFace[] {
  return knownFaces;
}

/**
 * Find the best matching user for a face descriptor
 * Returns the user if found, null otherwise
 */
export function findMatchingUser(descriptor: number[], threshold: number = 0.5): KnownFace | null {
  if (knownFaces.length === 0) {
    console.log("No known faces to match against");
    return null;
  }
  
  let bestMatch: { distance: number; user: KnownFace | null } = {
    distance: Number.MAX_VALUE,
    user: null
  };
  
  // Compare against all known users
  for (const user of knownFaces) {
    if (user.descriptors.length === 0) continue;
    
    // For each user, find the best matching descriptor
    for (const knownDescriptor of user.descriptors) {
      const distance = euclideanDistance(descriptor, knownDescriptor);
      
      if (distance < bestMatch.distance) {
        bestMatch = {
          distance,
          user
        };
      }
    }
  }
  
  // If the best match is below threshold, consider it a match
  if (bestMatch.distance < threshold) {
    console.log(`Found match: ${bestMatch.user?.name} with distance ${bestMatch.distance}`);
    return bestMatch.user;
  }
  
  console.log(`No match found. Best distance was ${bestMatch.distance}`);
  return null;
}

/**
 * Calculate Euclidean distance between two face descriptors
 */
function euclideanDistance(descriptor1: number[], descriptor2: number[]): number {
  if (!descriptor1 || !descriptor2 || descriptor1.length !== descriptor2.length) {
    throw new Error("Invalid descriptors for distance calculation");
  }
  
  let sum = 0;
  for (let i = 0; i < descriptor1.length; i++) {
    const diff = descriptor1[i] - descriptor2[i];
    sum += diff * diff;
  }
  
  return Math.sqrt(sum);
}

/**
 * Clear all known faces (for testing)
 */
export function clearKnownFaces(): void {
  knownFaces = [];
}

/**
 * Initialize with some test data if needed
 */
export function initTestFaces(): void {
  // Add test face data here if needed
  console.log("Initialized test face data");
}