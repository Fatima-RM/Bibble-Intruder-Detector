const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { storage } = require('./storage');

/**
 * Process known face images using Python's face_recognition library
 * and integrate the results into our database
 */
async function processFacesWithPython() {
  console.log('Processing face images with Python face_recognition...');
  
  try {
    // Create a temporary Python script
    const pythonScript = `
import face_recognition
import os
import json
import sys

def process_faces():
    base_dir = 'known_faces/fatima'
    persons = ['Fatima', 'Usman', 'Ahmad']
    results = {}
    
    for person in persons:
        person_dir = os.path.join(base_dir, person) if person != 'Ahmad' else base_dir
        person_images = []
        person_key = person.lower()
        
        if person == 'Ahmad':
            # Special case for Ahmad (Sir Ahmad Nawaz.jpg in base_dir)
            ahmad_img_path = os.path.join(base_dir, 'Sir Ahmad Nawaz.jpg')
            if os.path.exists(ahmad_img_path):
                try:
                    img = face_recognition.load_image_file(ahmad_img_path)
                    encodings = face_recognition.face_encodings(img)
                    if len(encodings) > 0:
                        person_images.append(encodings[0].tolist())
                        print(f"Processed Ahmad image: {ahmad_img_path}")
                except Exception as e:
                    print(f"Error processing {ahmad_img_path}: {str(e)}")
        else:
            # Process multiple images in person directory
            if os.path.isdir(person_dir):
                for file in os.listdir(person_dir):
                    if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                        img_path = os.path.join(person_dir, file)
                        try:
                            img = face_recognition.load_image_file(img_path)
                            encodings = face_recognition.face_encodings(img)
                            if len(encodings) > 0:
                                person_images.append(encodings[0].tolist())
                                print(f"Processed {person} image: {img_path}")
                            else:
                                print(f"No face found in {img_path}")
                        except Exception as e:
                            print(f"Error processing {img_path}: {str(e)}")
        
        if person_images:
            results[person_key] = person_images
            print(f"Extracted {len(person_images)} face descriptors for {person}")
        else:
            print(f"No face descriptors found for {person}")
    
    return results

if __name__ == "__main__":
    try:
        results = process_faces()
        print(json.dumps(results))
    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)
    `;
    
    const tempScriptPath = path.join(__dirname, 'temp_face_process.py');
    fs.writeFileSync(tempScriptPath, pythonScript);
    
    // Execute the Python script
    console.log('Executing Python face recognition script...');
    const output = execSync(`python ${tempScriptPath}`, { encoding: 'utf-8' });
    
    // Clean up temporary script
    fs.unlinkSync(tempScriptPath);
    
    // Parse the output JSON
    const jsonStart = output.lastIndexOf('{');
    const jsonEnd = output.lastIndexOf('}') + 1;
    
    if (jsonStart === -1 || jsonEnd === -1) {
      throw new Error('Could not find JSON output from Python script');
    }
    
    const jsonOutput = output.substring(jsonStart, jsonEnd);
    const faceData = JSON.parse(jsonOutput);
    
    console.log('Successfully extracted face descriptors:');
    for (const [person, descriptors] of Object.entries(faceData)) {
      console.log(`- ${person}: ${descriptors.length} descriptors`);
    }
    
    // Now update our database with these face descriptors
    await updateUsersWithFaceData(faceData);
    
    return faceData;
  } catch (error) {
    console.error('Error processing faces with Python:', error);
    throw error;
  }
}

/**
 * Update user records in the database with face descriptors
 */
async function updateUsersWithFaceData(faceData) {
  console.log('Updating users with face data...');
  
  try {
    const users = await storage.listUsers();
    
    for (const [username, descriptors] of Object.entries(faceData)) {
      // Find the corresponding user
      const user = users.find(user => 
        user.username.toLowerCase() === username.toLowerCase() ||
        (username === 'ahmad' && user.username.toLowerCase().includes('ahmad'))
      );
      
      if (user) {
        console.log(`Updating user ${user.name} (${user.username}) with ${descriptors.length} face descriptors`);
        
        const updatedFaceData = {
          descriptors: descriptors,
          timestamp: new Date().toISOString()
        };
        
        await storage.updateUser(user.id, {
          faceData: updatedFaceData,
          faceIdEnabled: true
        });
        
        console.log(`Updated user ${user.name} with face data`);
      } else {
        console.log(`No matching user found for ${username}`);
      }
    }
    
    console.log('All users updated with face data');
  } catch (error) {
    console.error('Error updating users with face data:', error);
    throw error;
  }
}

module.exports = { processFacesWithPython };