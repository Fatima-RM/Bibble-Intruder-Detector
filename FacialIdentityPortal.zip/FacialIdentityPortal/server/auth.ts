import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { User } from "@shared/schema";

// In a real production app, use environment variable for the secret
const JWT_SECRET = process.env.JWT_SECRET || "face-recognition-auth-secret";

export function generateToken(user: Omit<User, "password">): string {
  return jwt.sign(
    { 
      id: user.id, 
      username: user.username,
      email: user.email,
      name: user.name,
      faceIdEnabled: user.faceIdEnabled
    },
    JWT_SECRET,
    { expiresIn: "24h" }
  );
}

export function authenticateToken(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Authentication token required" });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    (req as any).user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ message: "Invalid or expired token" });
  }
}

// Utility to omit password from user object
export function sanitizeUser(user: User): Omit<User, "password"> {
  const { password, ...sanitizedUser } = user;
  return sanitizedUser;
}
