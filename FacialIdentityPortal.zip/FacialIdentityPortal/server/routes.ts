import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  loginSchema, 
  faceLoginSchema,
  insertActivitySchema 
} from "@shared/schema";
import jwt from "jsonwebtoken";
import session from "express-session";
import MemoryStore from "memorystore";

const JWT_SECRET = process.env.JWT_SECRET || "default-jwt-secret-key-for-development";

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session middleware
  const MemoryStoreSession = MemoryStore(session);
  app.use(
    session({
      cookie: { maxAge: 86400000 }, // 24 hours
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // 24 hours
      }),
      resave: false,
      saveUninitialized: false,
      secret: JWT_SECRET,
    })
  );

  // User registration
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already in use" });
      }
      
      const newUser = await storage.createUser(userData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = newUser;
      
      // Generate JWT token
      const token = jwt.sign({ id: newUser.id, username: newUser.username }, JWT_SECRET, {
        expiresIn: "24h",
      });
      
      // Set user in session
      req.session.user = userWithoutPassword;
      
      res.status(201).json({ 
        user: userWithoutPassword,
        token 
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ message: "Invalid registration data" });
    }
  });

  // Password login
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.verifyPassword(username, password);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      // Generate JWT token
      const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, {
        expiresIn: "24h",
      });
      
      // Set user in session
      req.session.user = userWithoutPassword;
      
      res.json({ 
        user: userWithoutPassword,
        token 
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(400).json({ message: "Invalid login data" });
    }
  });

  // Face ID login
  app.post("/api/auth/face-login", async (req: Request, res: Response) => {
    try {
      console.log("Face login attempt received");
      
      // Validate the request structure
      const { username, faceData } = faceLoginSchema.parse(req.body);
      
      if (!username) {
        console.log("Face login failed: Missing username");
        return res.status(400).json({ message: "Username is required" });
      }
      
      // Log details about the received face descriptor
      if (!faceData || !Array.isArray(faceData)) {
        console.log("Face login failed: Invalid face data format");
        return res.status(400).json({ message: "Face data is invalid" });
      }
      
      console.log(`Face login attempt for user: ${username}`);
      console.log(`Face descriptor received with ${faceData.length} points`);
      
      // Authorized users list for special handling
      const authorizedUsers = ['fatima', 'usman', 'ahmad'];
      const isAuthorizedUser = authorizedUsers.includes(username.toLowerCase());
      
      if (isAuthorizedUser) {
        console.log(`Special authorized user login attempt: ${username}`);
      }
      
      // Verify the face data against stored templates
      const user = await storage.verifyFaceData(username, faceData);
      
      if (!user) {
        console.log(`Face verification failed for user: ${username}`);
        return res.status(401).json({ message: "Face not recognized or user not found" });
      }
      
      // Log successful verification
      console.log(`Face verification successful for user: ${username} (ID: ${user.id})`);
      
      // Log activity in database
      try {
        await storage.logActivity({
          userId: user.id,
          activity: "Face login successful"
        });
      } catch (err) {
        console.error("Error logging activity:", err);
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      // Generate JWT token
      const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, {
        expiresIn: "24h",
      });
      
      // Set user in session
      req.session.user = userWithoutPassword;
      
      res.json({ 
        user: userWithoutPassword,
        token 
      });
    } catch (error) {
      console.error("Face login error:", error);
      if (error instanceof Error) {
        console.error("Error details:", error.message);
      }
      res.status(400).json({ message: "Invalid face login data" });
    }
  });

  // Logout
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // Get current user
  app.get("/api/auth/me", async (req: Request, res: Response) => {
    const user = req.session.user;
    if (!user) {
      // Log database access attempt in activities table
      try {
        await storage.logActivity({
          userId: 0, // for anonymous user
          activity: "Auth check (not authenticated)"
        });
        console.log("Successfully logged activity to database");
      } catch (error) {
        console.error("Error logging to database:", error);
      }
      
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json({ user });
  });

  // Update user
  app.put("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const user = req.session.user;
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = parseInt(req.params.id);
      
      // Only allow users to update their own profile
      if (user.id !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const userData = req.body;
      const updatedUser = await storage.updateUser(userId, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      
      // Update session
      req.session.user = userWithoutPassword;
      
      res.json({ user: userWithoutPassword });
    } catch (error) {
      console.error("Update user error:", error);
      res.status(400).json({ message: "Invalid update data" });
    }
  });

  // Get user activities
  app.get("/api/users/:id/activities", async (req: Request, res: Response) => {
    try {
      const user = req.session.user;
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = parseInt(req.params.id);
      
      // Only allow users to view their own activities
      if (user.id !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const activities = await storage.getUserActivities(userId);
      res.json({ activities });
    } catch (error) {
      console.error("Get activities error:", error);
      res.status(500).json({ message: "Failed to get activities" });
    }
  });

  // List all users (for admin purposes)
  app.get("/api/users", async (_req: Request, res: Response) => {
    try {
      const allUsers = await storage.listUsers();
      
      // Remove passwords from response
      const usersWithoutPasswords = allUsers.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.json({ users: usersWithoutPasswords });
    } catch (error) {
      console.error("List users error:", error);
      res.status(500).json({ message: "Failed to list users" });
    }
  });
  
  // Endpoint to get all known faces for recognition
  app.get("/api/known-faces", async (_req: Request, res: Response) => {
    try {
      // Get users that have face recognition enabled
      const users = await storage.listUsers();
      const facesData = users
        .filter(user => user.faceIdEnabled && user.faceData)
        .map(user => {
          return {
            userId: user.id,
            username: user.username,
            name: user.name,
            descriptors: user.faceData?.descriptors || []
          };
        });
      
      res.json({ knownFaces: facesData });
    } catch (error) {
      console.error("Error getting known faces:", error);
      res.status(500).json({ message: "Failed to get known faces" });
    }
  });
  
  // Endpoint to download face recognition data
  app.get("/api/download-faces", async (_req: Request, res: Response) => {
    try {
      // Get users that have face recognition enabled
      const users = await storage.listUsers();
      const facesData = users
        .filter(user => user.faceIdEnabled && user.faceData)
        .map(user => {
          return {
            userId: user.id,
            username: user.username,
            name: user.name,
            descriptors: user.faceData?.descriptors || []
          };
        });
      
      // Create a JSON file for download
      const jsonData = JSON.stringify({ knownFaces: facesData }, null, 2);
      
      // Set headers for file download
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename=face-recognition-data.json');
      
      // Send the file
      res.send(jsonData);
    } catch (error) {
      console.error("Error downloading face data:", error);
      res.status(500).json({ message: "Failed to download face data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
